<script setup>
import { computed, h, onMounted, ref, watch } from 'vue'
import { NButton, NCard, NDataTable, NPagination, NSelect, NSkeleton, NTag, useMessage } from 'naive-ui'
import { useRoute } from 'vue-router'
import ChartBox from './ChartBox.vue'
import DateRangeSwitch from './DateRangeSwitch.vue'
import { useIsMobile } from './useIsMobile'
import { api } from '../api/client'
import { notifyFeedbackHandled } from '../stores/adminBadges'
import { rangeOf, todayISO } from '../utils/date'

const message = useMessage()

const loading = ref(true)
const stats = ref(null)
const rows = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(10)
const rangeKey = ref('week')
const customRange = ref(null)
const category = ref('')
const handled = ref('')

const route = useRoute()
const isMobile = useIsMobile()

const range = computed(() => customRange.value || rangeOf(rangeKey.value === 'custom' ? 'week' : rangeKey.value))
const rangeText = computed(() => `${range.value.start} ~ ${range.value.end}`)

const CATEGORY_LABELS = {
  taste: '口味咸淡',
  oil: '菜品太油',
  fresh: '食材新鲜度',
  hygiene: '卫生问题',
  tableware: '餐具问题',
  other: '其他建议',
}

const categoryOptions = [
  { label: '全部类型', value: '' },
  ...Object.entries(CATEGORY_LABELS).map(([value, label]) => ({ label, value })),
]

const handledOptions = [
  { label: '全部状态', value: '' },
  { label: '待处理', value: 'false' },
  { label: '已处理', value: 'true' },
]

const statCards = computed(() => {
  const data = stats.value
  if (!data) return []
  return [
    { label: '区间反馈', value: data.total, unit: '条', foot: rangeText.value },
    // 待处理按「全部日期」统计，和下方列表标题上的胶囊保持一致（区间内可能一条都没有）
    { label: '待处理', value: data.pending_all ?? data.pending, unit: '条', foot: '全部日期，未处理' },
    { label: '已处理', value: data.handled, unit: '条' },
    { label: '本周新增', value: data.this_week, unit: '条' },
  ]
})

const categoryOption = computed(() => {
  const data = stats.value?.by_category || []
  return {
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: 8, right: 24, top: 10, bottom: 6, containLabel: true },
    xAxis: { type: 'value', splitLine: { lineStyle: { color: '#f1f4f9' } }, axisLabel: { color: '#93a1b5' } },
    yAxis: {
      type: 'category',
      data: data.map((item) => item.label),
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { color: '#5b6a80' },
    },
    series: [
      {
        type: 'bar',
        barWidth: 14,
        label: { show: true, position: 'right', color: '#7d8ba1', fontSize: 11 },
        itemStyle: {
          borderRadius: [0, 8, 8, 0],
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 1,
            y2: 0,
            colorStops: [
              { offset: 0, color: '#1f6feb' },
              { offset: 1, color: '#63a9ff' },
            ],
          },
        },
        data: data.map((item) => item.count),
      },
    ],
  }
})

const trendOption = computed(() => {
  const series = stats.value?.series || []
  return {
    tooltip: { trigger: 'axis' },
    grid: { left: 8, right: 16, top: 20, bottom: 6, containLabel: true },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: series.map((item) => item.date.slice(5)),
      axisLine: { lineStyle: { color: '#e6ebf3' } },
      axisTick: { show: false },
      axisLabel: { color: '#93a1b5', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      splitLine: { lineStyle: { color: '#f1f4f9' } },
      axisLabel: { color: '#93a1b5', fontSize: 11 },
    },
    series: [
      {
        type: 'line',
        smooth: true,
        showSymbol: false,
        lineStyle: { width: 2.4, color: '#1f6feb' },
        itemStyle: { color: '#1f6feb' },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: '#1f6feb33' },
              { offset: 1, color: '#1f6feb00' },
            ],
          },
        },
        data: series.map((item) => item.count),
      },
    ],
  }
})

const columns = [
  {
    title: '内容',
    key: 'content',
    minWidth: 320,
    render: (row) =>
      h('div', null, [
        h('div', { style: 'display:flex;align-items:center;gap:8px;margin-bottom:4px' }, [
          h(NTag, { size: 'small', bordered: false, type: 'info', round: true }, { default: () => row.category_label }),
          h('span', { class: 'cell-sub' }, (row.created_at || '').replace('T', ' ').slice(0, 16)),
        ]),
        h('div', { style: 'font-size:13px;color:#33404f;line-height:1.6' }, row.content),
      ]),
  },
  { title: '日期', key: 'date', width: 120 },
  {
    title: '状态',
    key: 'handled',
    width: 100,
    render: (row) =>
      h(
        NTag,
        { size: 'small', bordered: false, round: true, type: row.handled ? 'success' : 'warning' },
        { default: () => (row.handled ? '已处理' : '待处理') },
      ),
  },
  {
    title: '操作',
    key: 'actions',
    width: 120,
    render: (row) =>
      row.handled
        ? h('span', { class: 'cell-sub' }, '已归档')
        : h(
            NButton,
            { size: 'tiny', type: 'primary', secondary: true, onClick: () => markHandled(row) },
            { default: () => '标记已处理' },
          ),
  },
]

const pagination = computed(() => ({
  page: page.value,
  pageSize: pageSize.value,
  itemCount: total.value,
  pageSizes: [10, 20, 50],
  prefix: () => `共 ${total.value} 条`,
  onUpdatePage: (value) => {
    page.value = value
    loadList()
  },
  onUpdatePageSize: (value) => {
    pageSize.value = value
    page.value = 1
    loadList()
  },
}))

/** n-data-table remote 分页时必须显式声明，否则分页器不出现/翻页无效 */
const remote = computed(() => true)

async function loadStats() {
  stats.value = await api.get(
    '/feedback/stats',
    { start: range.value.start, end: range.value.end },
    'admin',
  )
}

/**
 * 列表与上面的统计面板口径不同，这是有意为之：
 * - 上方面板（指标卡 + 图表）跟随顶部日期区间；
 * - 下方列表**始终覆盖全部日期**，只受「类型 / 状态」筛选影响，
 *   这样历史遗留的待处理反馈永远能在列表里找到，不会被日期区间藏起来。
 */
async function loadList() {
  loading.value = true
  try {
    const params = {
      page: page.value,
      page_size: pageSize.value,
      category: category.value,
    }
    if (handled.value) params.handled = handled.value
    const data = await api.get('/feedback', params, 'admin')
    rows.value = data.items
    total.value = data.total
  } catch (error) {
    message.error(error.message)
  } finally {
    loading.value = false
  }
}

/** 日期区间只刷新上方面板，不动列表 */
function onRangeChange({ key, start, end }) {
  rangeKey.value = key
  customRange.value = key === 'custom' ? { start, end } : null
  loadStats()
}

function onStatusChange(value) {
  handled.value = value
  page.value = 1
  loadList()
}

/** 列表标题上的「待处理 N 条」：点一下只看待处理 */
function filterPending() {
  handled.value = handled.value === 'false' ? '' : 'false'
  page.value = 1
  loadList()
}

async function reload() {
  page.value = 1
  await Promise.all([loadStats(), loadList()])
}

/** 标记为已处理：单向操作。小红点数量本地实时减一（归零立即消失），再向服务端核对 */
async function markHandled(row) {
  try {
    const result = await api.put(`/feedback/${row.id}/handled`, undefined, 'admin')
    row.handled = true
    notifyFeedbackHandled()
    await loadStats()
    const left = stats.value?.pending_all ?? 0
    if (left > 0) {
      message.success(`${result?.message || '已标记为已处理'}，还剩 ${left} 条待处理`)
    } else {
      message.success('已全部处理完毕')
    }
    // 正在看「待处理」时，处理掉的行要从列表里移除
    if (handled.value === 'false') loadList()
  } catch (error) {
    message.error(error.message)
  }
}

function clearFilters() {
  category.value = ''
  handled.value = ''
  page.value = 1
  loadList()
}

/** 手机端卡片列表的翻页 */
function onPageChange(value) {
  page.value = value
  loadList()
}

onMounted(() => {
  // 支持从导航小红点直接带着「待处理」筛选进入
  if (route.query.handled === 'false') handled.value = 'false'
  reload()
})
</script>

<template>
  <div class="admin-page">
    <div class="page-head">
      <div>
        <h2>意见反馈</h2>
        <p>员工匿名反馈，后台只看到内容与类型，看不到提交人（保护反馈真实度）</p>
      </div>
      <div class="page-actions">
        <DateRangeSwitch v-model="rangeKey" @change="onRangeChange" />
      </div>
    </div>

    <n-skeleton v-if="!stats" height="110px" :sharp="false" />
    <div v-else class="stat-grid">
      <div v-for="item in statCards" :key="item.label" class="stat">
        <div class="stat-label">{{ item.label }}</div>
        <div class="stat-value">{{ item.value }}<small>{{ item.unit }}</small></div>
        <div v-if="item.foot" class="stat-foot">{{ item.foot }}</div>
      </div>
    </div>

    <div class="two-col">
      <n-card :bordered="false">
        <template #header>
          <div class="panel-title"><i />反馈类型分布</div>
        </template>
        <ChartBox :option="categoryOption" height="240px" />
      </n-card>
      <n-card :bordered="false">
        <template #header>
          <div class="panel-title"><i />反馈趋势</div>
        </template>
        <ChartBox :option="trendOption" height="240px" />
      </n-card>
    </div>

    <n-card :bordered="false">
      <template #header>
        <div class="panel-head">
          <div class="panel-title">
            <i />反馈列表
            <span class="panel-sub">共 {{ total }} 条 · 全部日期</span>
            <button
              v-if="stats?.pending_all || handled === 'false'"
              type="button"
              class="pending-pill"
              :class="{ active: handled === 'false' }"
              :title="handled === 'false' ? '取消「只看待处理」，回到全部状态' : '只看待处理'"
              @click="filterPending"
            >
              待处理 {{ stats?.pending_all ?? 0 }} 条
            </button>
          </div>
          <div class="toolbar">
            <n-select
              v-model:value="category"
              :options="categoryOptions"
              size="small"
              style="width: 140px"
              @update:value="loadList"
            />
            <n-select
              :value="handled"
              :options="handledOptions"
              size="small"
              style="width: 120px"
              @update:value="onStatusChange"
            />
            <n-button size="small" quaternary @click="clearFilters">重置</n-button>
          </div>
        </div>
      </template>

      <n-skeleton v-if="loading" text :repeat="5" />
      <template v-else>
        <!-- 手机端：卡片列表，比横向滚动的表格好读 -->
        <div v-if="isMobile" class="fb-cards">
          <article v-for="row in rows" :key="row.id" class="fb-card">
            <div class="fb-card-top">
              <span class="chip">{{ row.category_label }}</span>
              <span class="chip" :class="row.handled ? 'ok' : 'warn'">
                {{ row.handled ? '已处理' : '待处理' }}
              </span>
              <span class="muted tiny">{{ row.date }}</span>
            </div>
            <p class="fb-card-text">{{ row.content }}</p>
            <div class="fb-card-foot">
              <span class="muted tiny">{{ (row.created_at || '').replace('T', ' ').slice(0, 16) }}</span>
              <n-button
                v-if="!row.handled"
                size="small"
                type="primary"
                secondary
                @click="markHandled(row)"
              >
                标记已处理
              </n-button>
              <span v-else class="muted tiny">已归档</span>
            </div>
          </article>
          <div v-if="!rows.length" class="empty-box">没有符合条件的反馈</div>
          <n-pagination
            v-if="total > pageSize"
            :page="page"
            :page-size="pageSize"
            :item-count="total"
            :page-slot="5"
            class="fb-pager"
            @update:page="onPageChange"
          />
        </div>

        <n-data-table
          v-else
          :columns="columns"
          :data="rows"
          :bordered="false"
          size="small"
          :row-key="(row) => row.id"
          remote
          :scroll-x="720"
          :pagination="pagination"
        />
        <div v-if="!isMobile && !rows.length" class="empty-box">没有符合条件的反馈</div>
      </template>
    </n-card>
  </div>
</template>

<style scoped>
.two-col {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
  gap: 16px;
}

/* 列表标题上的「待处理 N 条」：点一下只看待处理，再点取消 */
.pending-pill {
  margin-left: 8px;
  border: 1px solid #f3d6d6;
  background: #fff5f5;
  color: #c0392b;
  font-size: 12px;
  font-weight: 600;
  padding: 3px 9px;
  border-radius: 999px;
  cursor: pointer;
  transition: 0.15s;
  vertical-align: 1px;
}

.pending-pill:hover {
  background: #fdecec;
}

.pending-pill.active {
  background: #c0392b;
  border-color: #c0392b;
  color: #fff;
}

/* ── 手机端反馈卡片 ─────────────────────── */
.fb-cards {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.fb-card {
  border: 1px solid #eceef2;
  border-radius: 10px;
  padding: 11px 12px;
  background: #fff;
}

.fb-card-top {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
  margin-bottom: 7px;
}

.fb-card-text {
  margin: 0 0 8px;
  font-size: 13.5px;
  line-height: 1.65;
  color: #2b3441;
  word-break: break-word;
}

.fb-card-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.fb-pager {
  display: flex;
  justify-content: center;
  margin-top: 12px;
}
</style>

import{A as e,E as t,H as n,I as r,M as i,Q as a,S as o,U as s,X as c,Y as l,at as u,b as d,ct as f,k as p,m,o as h,pt as g,u as _,v,y}from"./vue-vendor-BGcTsaF8.js";import{$ as b,At as x,Dt as S,Et as C,K as w,P as T,R as E,Sn as D,St as O,U as k,X as A,_t as ee,at as j,cn as M,ct as N,dn as P,fr as F,gn as I,gr as L,hr as R,i as z,jt as te,kt as B,lt as V,mn as H,ot as U,pr as W,q as ne,un as G,vt as K,xt as q}from"./Skeleton-DVjzRZkO.js";import{u as J}from"./Tag-BOvzHE0n.js";import{r as Y,t as X}from"./use-is-composing-oO7t4Glq.js";function re(e){let{modalColor:t,textColor1:n,textColor2:r,boxShadow3:i,lineHeight:a,fontWeightStrong:o,dividerColor:s,closeColorHover:c,closeColorPressed:l,closeIconColor:u,closeIconColorHover:d,closeIconColorPressed:f,borderRadius:p,primaryColorHover:m}=e;return{bodyPadding:`16px 24px`,borderRadius:p,headerPadding:`16px 24px`,footerPadding:`16px 24px`,color:t,textColor:r,titleTextColor:n,titleFontSize:`18px`,titleFontWeight:o,boxShadow:i,lineHeight:a,headerBorderBottom:`1px solid ${s}`,footerBorderTop:`1px solid ${s}`,closeIconColor:u,closeIconColorHover:d,closeIconColorPressed:f,closeSize:`22px`,closeIconSize:`18px`,closeColorHover:c,closeColorPressed:l,closeBorderRadius:p,resizableTriggerColorHover:m}}var ie=C({name:`Drawer`,common:te,peers:{Scrollbar:x},self:re}),ae=[`onMouseenter`,`onMouseleave`,`onMousedown`],oe={key:1,role:`none`},se=t({name:`NDrawerContent`,inheritAttrs:!1,props:{blockScroll:Boolean,show:{type:Boolean,default:void 0},displayDirective:{type:String,required:!0},placement:{type:String,required:!0},contentClass:String,contentStyle:[Object,String],nativeScrollbar:{type:Boolean,required:!0},scrollbarProps:Object,trapFocus:{type:Boolean,default:!0},autoFocus:{type:Boolean,default:!0},showMask:{type:[Boolean,String],required:!0},maxWidth:Number,maxHeight:Number,minWidth:Number,minHeight:Number,resizable:Boolean,onClickoutside:Function,onAfterLeave:Function,onAfterEnter:Function,onEsc:Function},setup(t){let n=u(!!t.show),i=u(null),a=e(O),o=0,d=``,f=null,p=u(!1),m=u(!1),h=v(()=>t.placement===`top`||t.placement===`bottom`),{mergedClsPrefixRef:g,mergedRtlRef:y}=I(t),x=b(`Drawer`,y,g),S=M,C=e=>{m.value=!0,o=h.value?e.clientY:e.clientX,d=document.body.style.cursor,document.body.style.cursor=h.value?`ns-resize`:`ew-resize`,document.body.addEventListener(`mousemove`,j),document.body.addEventListener(`mouseleave`,S),document.body.addEventListener(`mouseup`,M)},w=()=>{f!==null&&(window.clearTimeout(f),f=null),m.value?p.value=!0:f=window.setTimeout(()=>{p.value=!0},300)},T=()=>{f!==null&&(window.clearTimeout(f),f=null),p.value=!1},{doUpdateHeight:E,doUpdateWidth:D}=a,k=e=>{let{maxWidth:n}=t;if(n&&e>n)return n;let{minWidth:r}=t;return r&&e<r?r:e},A=e=>{let{maxHeight:n}=t;if(n&&e>n)return n;let{minHeight:r}=t;return r&&e<r?r:e};function j(e){if(m.value){if(h.value){let n=i.value?.offsetHeight||0,r=o-e.clientY;n+=t.placement===`bottom`?r:-r,n=A(n),E(n),o=e.clientY}else{let n=i.value?.offsetWidth||0,r=o-e.clientX;n+=t.placement===`right`?r:-r,n=k(n),D(n),o=e.clientX}}}function M(){m.value&&(o=0,m.value=!1,document.body.style.cursor=d,document.body.removeEventListener(`mousemove`,j),document.body.removeEventListener(`mouseup`,M),document.body.removeEventListener(`mouseleave`,S))}c(()=>{t.show&&(n.value=!0)}),l(()=>t.show,e=>{e||M()}),r(()=>{M()});let N=v(()=>{let{show:e}=t,n=[[_,e]];return t.showMask||n.push([ne,t.onClickoutside,void 0,{capture:!0}]),n});function P(){n.value=!1,t.onAfterLeave?.()}return Y(v(()=>t.blockScroll&&n.value)),s(q,i),s(ee,null),s(K,null),{bodyRef:i,rtlEnabled:x,mergedClsPrefix:a.mergedClsPrefixRef,isMounted:a.isMountedRef,mergedTheme:a.mergedThemeRef,displayed:n,transitionName:v(()=>({right:`slide-in-from-right-transition`,left:`slide-in-from-left-transition`,top:`slide-in-from-top-transition`,bottom:`slide-in-from-bottom-transition`})[t.placement]),handleAfterLeave:P,bodyDirectives:N,handleMousedownResizeTrigger:C,handleMouseenterResizeTrigger:w,handleMouseleaveResizeTrigger:T,isDragging:m,isHoverOnResizeTrigger:p}},render(){let{$slots:e,mergedClsPrefix:t}=this;return this.displayDirective===`show`||this.displayed||this.show?a((n(),o(`div`,oe,[(n(),d(J,{disabled:!this.showMask||!this.trapFocus,active:this.show,autoFocus:this.autoFocus,onEsc:this.onEsc},{default:()=>(n(),d(h,{name:this.transitionName,appear:this.isMounted,onAfterEnter:this.onAfterEnter,onAfterLeave:this.handleAfterLeave},{default:()=>a(p(`div`,i(this.$attrs,{role:`dialog`,ref:`bodyRef`,"aria-modal":`true`,class:[`${t}-drawer`,this.rtlEnabled&&`${t}-drawer--rtl`,`${t}-drawer--${this.placement}-placement`,this.isDragging&&`${t}-drawer--unselectable`,this.nativeScrollbar&&`${t}-drawer--native-scrollbar`]}),[this.resizable?(n(),o(`div`,{key:2,class:M([`${t}-drawer__resize-trigger`,(this.isDragging||this.isHoverOnResizeTrigger)&&`${t}-drawer__resize-trigger--hover`]),onMouseenter:this.handleMouseenterResizeTrigger,onMouseleave:this.handleMouseleaveResizeTrigger,onMousedown:this.handleMousedownResizeTrigger},null,42,ae)):null,this.nativeScrollbar?(n(),o(`div`,{key:3,class:M([`${t}-drawer-content-wrapper`,this.contentClass]),style:g(this.contentStyle),role:`none`},[P(()=>e.default?.())],6)):(n(),d(E,i({key:4},this.scrollbarProps,{contentStyle:this.contentStyle,contentClass:[`${t}-drawer-content-wrapper`,this.contentClass],theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar}),G(e),1040,[`contentStyle`,`contentClass`,`theme`,`themeOverrides`]))]),this.bodyDirectives)},1032,[`name`,`appear`,`onAfterEnter`,`onAfterLeave`]))},1032,[`disabled`,`active`,`autoFocus`,`onEsc`]))])),[[_,this.displayDirective===`if`||this.displayed||this.show]]):null}}),{cubicBezierEaseIn:ce,cubicBezierEaseOut:le}=H;function ue({duration:e=`0.3s`,leaveDuration:t=`0.2s`,name:n=`slide-in-from-bottom`}={}){return[F(`&.${n}-transition-leave-active`,{transition:`transform ${t} ${ce}`}),F(`&.${n}-transition-enter-active`,{transition:`transform ${e} ${le}`}),F(`&.${n}-transition-enter-to`,{transform:`translateY(0)`}),F(`&.${n}-transition-enter-from`,{transform:`translateY(100%)`}),F(`&.${n}-transition-leave-from`,{transform:`translateY(0)`}),F(`&.${n}-transition-leave-to`,{transform:`translateY(100%)`})]}var{cubicBezierEaseIn:de,cubicBezierEaseOut:fe}=H;function pe({duration:e=`0.3s`,leaveDuration:t=`0.2s`,name:n=`slide-in-from-left`}={}){return[F(`&.${n}-transition-leave-active`,{transition:`transform ${t} ${de}`}),F(`&.${n}-transition-enter-active`,{transition:`transform ${e} ${fe}`}),F(`&.${n}-transition-enter-to`,{transform:`translateX(0)`}),F(`&.${n}-transition-enter-from`,{transform:`translateX(-100%)`}),F(`&.${n}-transition-leave-from`,{transform:`translateX(0)`}),F(`&.${n}-transition-leave-to`,{transform:`translateX(-100%)`})]}var{cubicBezierEaseIn:me,cubicBezierEaseOut:he}=H;function Z({duration:e=`0.3s`,leaveDuration:t=`0.2s`,name:n=`slide-in-from-right`}={}){return[F(`&.${n}-transition-leave-active`,{transition:`transform ${t} ${me}`}),F(`&.${n}-transition-enter-active`,{transition:`transform ${e} ${he}`}),F(`&.${n}-transition-enter-to`,{transform:`translateX(0)`}),F(`&.${n}-transition-enter-from`,{transform:`translateX(100%)`}),F(`&.${n}-transition-leave-from`,{transform:`translateX(0)`}),F(`&.${n}-transition-leave-to`,{transform:`translateX(100%)`})]}var{cubicBezierEaseIn:ge,cubicBezierEaseOut:_e}=H;function ve({duration:e=`0.3s`,leaveDuration:t=`0.2s`,name:n=`slide-in-from-top`}={}){return[F(`&.${n}-transition-leave-active`,{transition:`transform ${t} ${ge}`}),F(`&.${n}-transition-enter-active`,{transition:`transform ${e} ${_e}`}),F(`&.${n}-transition-enter-to`,{transform:`translateY(0)`}),F(`&.${n}-transition-enter-from`,{transform:`translateY(-100%)`}),F(`&.${n}-transition-leave-from`,{transform:`translateY(0)`}),F(`&.${n}-transition-leave-to`,{transform:`translateY(-100%)`})]}var ye=F([W(`drawer`,`
 word-break: break-word;
 line-height: var(--n-line-height);
 position: absolute;
 pointer-events: all;
 box-shadow: var(--n-box-shadow);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 background-color: var(--n-color);
 color: var(--n-text-color);
 box-sizing: border-box;
 `,[Z(),pe(),ve(),ue(),L(`unselectable`,`
 user-select: none; 
 -webkit-user-select: none;
 `),L(`native-scrollbar`,[W(`drawer-content-wrapper`,`
 overflow: auto;
 height: 100%;
 `)]),R(`resize-trigger`,`
 position: absolute;
 background-color: #0000;
 transition: background-color .3s var(--n-bezier);
 `,[L(`hover`,`
 background-color: var(--n-resize-trigger-color-hover);
 `)]),W(`drawer-content-wrapper`,`
 box-sizing: border-box;
 `),W(`drawer-content`,`
 height: 100%;
 display: flex;
 flex-direction: column;
 `,[L(`native-scrollbar`,[W(`drawer-body-content-wrapper`,`
 height: 100%;
 overflow: auto;
 `)]),W(`drawer-body`,`
 flex: 1 0 0;
 overflow: hidden;
 `),W(`drawer-body-content-wrapper`,`
 box-sizing: border-box;
 padding: var(--n-body-padding);
 `),W(`drawer-header`,`
 font-weight: var(--n-title-font-weight);
 line-height: 1;
 font-size: var(--n-title-font-size);
 color: var(--n-title-text-color);
 padding: var(--n-header-padding);
 transition: border .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-divider-color);
 border-bottom: var(--n-header-border-bottom);
 display: flex;
 justify-content: space-between;
 align-items: center;
 `,[R(`main`,`
 flex: 1;
 `),R(`close`,`
 margin-left: 6px;
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `)]),W(`drawer-footer`,`
 display: flex;
 justify-content: flex-end;
 border-top: var(--n-footer-border-top);
 transition: border .3s var(--n-bezier);
 padding: var(--n-footer-padding);
 `)]),L(`right-placement`,`
 top: 0;
 bottom: 0;
 right: 0;
 border-top-left-radius: var(--n-border-radius);
 border-bottom-left-radius: var(--n-border-radius);
 `,[R(`resize-trigger`,`
 width: 3px;
 height: 100%;
 top: 0;
 left: 0;
 transform: translateX(-1.5px);
 cursor: ew-resize;
 `)]),L(`left-placement`,`
 top: 0;
 bottom: 0;
 left: 0;
 border-top-right-radius: var(--n-border-radius);
 border-bottom-right-radius: var(--n-border-radius);
 `,[R(`resize-trigger`,`
 width: 3px;
 height: 100%;
 top: 0;
 right: 0;
 transform: translateX(1.5px);
 cursor: ew-resize;
 `)]),L(`top-placement`,`
 top: 0;
 left: 0;
 right: 0;
 border-bottom-left-radius: var(--n-border-radius);
 border-bottom-right-radius: var(--n-border-radius);
 `,[R(`resize-trigger`,`
 width: 100%;
 height: 3px;
 bottom: 0;
 left: 0;
 transform: translateY(1.5px);
 cursor: ns-resize;
 `)]),L(`bottom-placement`,`
 left: 0;
 bottom: 0;
 right: 0;
 border-top-left-radius: var(--n-border-radius);
 border-top-right-radius: var(--n-border-radius);
 `,[R(`resize-trigger`,`
 width: 100%;
 height: 3px;
 top: 0;
 left: 0;
 transform: translateY(-1.5px);
 cursor: ns-resize;
 `)])]),F(`body`,[F(`>`,[W(`drawer-container`,`
 position: fixed;
 `)])]),W(`drawer-container`,`
 position: relative;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 `,[F(`> *`,`
 pointer-events: all;
 `)]),W(`drawer-mask`,`
 background-color: rgba(0, 0, 0, .3);
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `,[L(`invisible`,`
 background-color: rgba(0, 0, 0, 0)
 `),A({enterDuration:`0.2s`,leaveDuration:`0.2s`,enterCubicBezier:`var(--n-bezier-in)`,leaveCubicBezier:`var(--n-bezier-out)`})])]),be=[`onClick`],Q={...S.props,show:Boolean,width:[Number,String],height:[Number,String],placement:{type:String,default:`right`},maskClosable:{type:Boolean,default:!0},showMask:{type:[Boolean,String],default:!0},to:[String,Object],displayDirective:{type:String,default:`if`},nativeScrollbar:{type:Boolean,default:!0},zIndex:Number,onMaskClick:Function,scrollbarProps:Object,contentClass:String,contentStyle:[Object,String],trapFocus:{type:Boolean,default:!0},onEsc:Function,autoFocus:{type:Boolean,default:!0},closeOnEsc:{type:Boolean,default:!0},blockScroll:{type:Boolean,default:!0},maxWidth:Number,maxHeight:Number,minWidth:Number,minHeight:Number,resizable:Boolean,defaultWidth:{type:[Number,String],default:251},defaultHeight:{type:[Number,String],default:251},onUpdateWidth:[Function,Array],onUpdateHeight:[Function,Array],"onUpdate:width":[Function,Array],"onUpdate:height":[Function,Array],"onUpdate:show":[Function,Array],onUpdateShow:[Function,Array],onAfterEnter:Function,onAfterLeave:Function,drawerStyle:[String,Object],drawerClass:String,target:null,onShow:Function,onHide:Function},xe=t({name:`Drawer`,inheritAttrs:!1,props:Q,setup(e){let{mergedClsPrefixRef:t,namespaceRef:n,inlineThemeDisabled:r}=I(e),i=N(),a=S(`Drawer`,`-drawer`,ye,ie,e,t),o=u(e.defaultWidth),c=u(e.defaultHeight),l=V(f(e,`width`),o),d=V(f(e,`height`),c),p=v(()=>{let{placement:t}=e;return t===`top`||t===`bottom`?``:j(l.value)}),m=v(()=>{let{placement:t}=e;return t===`left`||t===`right`?``:j(d.value)}),h=t=>{let{onUpdateWidth:n,"onUpdate:width":r}=e;n&&U(n,t),r&&U(r,t),o.value=t},g=t=>{let{onUpdateHeight:n,"onUpdate:width":r}=e;n&&U(n,t),r&&U(r,t),c.value=t},_=v(()=>[{width:p.value,height:m.value},e.drawerStyle||``]);function y(t){let{onMaskClick:n,maskClosable:r}=e;r&&w(!1),n&&n(t)}function b(e){y(e)}let x=X();function C(t){e.onEsc?.(),e.show&&e.closeOnEsc&&z(t)&&(x.value||w(!1))}function w(t){let{onHide:n,onUpdateShow:r,"onUpdate:show":i}=e;r&&U(r,t),i&&U(i,t),n&&!t&&U(n,t)}s(O,{isMountedRef:i,mergedThemeRef:a,mergedClsPrefixRef:t,doUpdateShow:w,doUpdateHeight:g,doUpdateWidth:h});let T=v(()=>{let{common:{cubicBezierEaseInOut:e,cubicBezierEaseIn:t,cubicBezierEaseOut:n},self:{color:r,textColor:i,boxShadow:o,lineHeight:s,headerPadding:c,footerPadding:l,borderRadius:u,bodyPadding:d,titleFontSize:f,titleTextColor:p,titleFontWeight:m,headerBorderBottom:h,footerBorderTop:g,closeIconColor:_,closeIconColorHover:v,closeIconColorPressed:y,closeColorHover:b,closeColorPressed:x,closeIconSize:S,closeSize:C,closeBorderRadius:w,resizableTriggerColorHover:T}}=a.value;return{"--n-line-height":s,"--n-color":r,"--n-border-radius":u,"--n-text-color":i,"--n-box-shadow":o,"--n-bezier":e,"--n-bezier-out":n,"--n-bezier-in":t,"--n-header-padding":c,"--n-body-padding":d,"--n-footer-padding":l,"--n-title-text-color":p,"--n-title-font-size":f,"--n-title-font-weight":m,"--n-header-border-bottom":h,"--n-footer-border-top":g,"--n-close-icon-color":_,"--n-close-icon-color-hover":v,"--n-close-icon-color-pressed":y,"--n-close-size":C,"--n-close-color-hover":b,"--n-close-color-pressed":x,"--n-close-icon-size":S,"--n-close-border-radius":w,"--n-resize-trigger-color-hover":T}}),E=r?B(`drawer`,void 0,T,e):void 0;return{mergedClsPrefix:t,namespace:n,mergedBodyStyle:_,handleOutsideClick:b,handleMaskClick:y,handleEsc:C,mergedTheme:a,cssVars:r?void 0:T,themeClass:E?.themeClass,onRender:E?.onRender,isMounted:i}},render(){let{mergedClsPrefix:e}=this;return n(),d(k,{to:this.to,show:this.show},{default:()=>(this.onRender?.(),a((n(),o(`div`,{class:M([`${e}-drawer-container`,this.namespace,this.themeClass]),style:g(this.cssVars),role:`none`},[this.showMask?(n(),d(h,{key:0,name:`fade-in-transition`,appear:this.isMounted},{default:()=>this.show?(n(),o(`div`,{key:1,"aria-hidden":!0,class:M([`${e}-drawer-mask`,this.showMask===`transparent`&&`${e}-drawer-mask--invisible`]),onClick:this.handleMaskClick},null,10,be)):null},1032,[`appear`])):P(()=>null),(n(),d(se,i(this.$attrs,{class:[this.drawerClass,this.$attrs.class],style:[this.mergedBodyStyle,this.$attrs.style],blockScroll:this.blockScroll,contentStyle:this.contentStyle,contentClass:this.contentClass,placement:this.placement,scrollbarProps:this.scrollbarProps,show:this.show,displayDirective:this.displayDirective,nativeScrollbar:this.nativeScrollbar,onAfterEnter:this.onAfterEnter,onAfterLeave:this.onAfterLeave,trapFocus:this.trapFocus,autoFocus:this.autoFocus,resizable:this.resizable,maxHeight:this.maxHeight,minHeight:this.minHeight,maxWidth:this.maxWidth,minWidth:this.minWidth,showMask:this.showMask,onEsc:this.handleEsc,onClickoutside:this.handleOutsideClick}),G(this.$slots),1040,[`class`,`style`,`blockScroll`,`contentStyle`,`contentClass`,`placement`,`scrollbarProps`,`show`,`displayDirective`,`nativeScrollbar`,`onAfterEnter`,`onAfterLeave`,`trapFocus`,`autoFocus`,`resizable`,`maxHeight`,`minHeight`,`maxWidth`,`minWidth`,`showMask`,`onEsc`,`onClickoutside`]))],6)),[[w,{zIndex:this.zIndex,enabled:this.show}]]))},1032,[`to`,`show`])}}),$={title:String,headerClass:String,headerStyle:[Object,String],footerClass:String,footerStyle:[Object,String],bodyClass:String,bodyStyle:[Object,String],bodyContentClass:String,bodyContentStyle:[Object,String],nativeScrollbar:{type:Boolean,default:!0},scrollbarProps:Object,closable:Boolean},Se=t({name:`DrawerContent`,props:$,slots:Object,setup(){let t=e(O,null);t||D(`drawer-content`,"`n-drawer-content` must be placed inside `n-drawer`.");let{doUpdateShow:n}=t;function r(){n(!1)}return{handleCloseClick:r,mergedTheme:t.mergedThemeRef,mergedClsPrefix:t.mergedClsPrefixRef}},render(){let{title:e,mergedClsPrefix:t,nativeScrollbar:r,mergedTheme:a,bodyClass:s,bodyStyle:c,bodyContentClass:l,bodyContentStyle:u,headerClass:f,headerStyle:p,footerClass:h,footerStyle:_,scrollbarProps:v,closable:b,$slots:x}=this;return n(),o(`div`,{role:`none`,class:M([`${t}-drawer-content`,r&&`${t}-drawer-content--native-scrollbar`])},[x.header||e||b?(n(),o(`div`,{key:0,class:M([`${t}-drawer-header`,f]),style:g(p),role:`none`},[y(`div`,{class:M(`${t}-drawer-header__main`),role:`heading`,"aria-level":`1`},[x.header===void 0?(n(),o(m,{key:1},[P(()=>e)],64)):(n(),o(m,{key:0},[P(()=>x.header())],64))],2),P(()=>b&&(n(),d(T,{onClick:this.handleCloseClick,clsPrefix:t,class:M(`${t}-drawer-header__close`),absolute:!0},null,8,[`onClick`,`clsPrefix`,`class`])))],6)):P(()=>null),r?(n(),o(`div`,{key:2,class:M([`${t}-drawer-body`,s]),style:g(c),role:`none`},[y(`div`,{class:M([`${t}-drawer-body-content-wrapper`,l]),style:g(u),role:`none`},[P(()=>x.default?.())],6)],6)):(n(),d(E,i({key:3,themeOverrides:a.peerOverrides.Scrollbar,theme:a.peers.Scrollbar},v,{class:`${t}-drawer-body`,contentClass:[`${t}-drawer-body-content-wrapper`,l],contentStyle:u}),G(x),1040,[`themeOverrides`,`theme`,`class`,`contentClass`,`contentStyle`])),x.footer?(n(),o(`div`,{key:4,class:M([`${t}-drawer-footer`,h]),style:g(_),role:`none`},[P(()=>x.footer())],6)):P(()=>null)],2)}});export{Q as i,$ as n,xe as r,Se as t};
import{Dt as e,_r as t,cn as n,dn as r,gn as i,gr as a,hr as o,jt as s,kt as c,pr as l}from"./Skeleton-DVjzRZkO.js";import{E as u,H as d,S as f,m as p,pt as m,v as h,y as g}from"./vue-vendor-BGcTsaF8.js";function _(e){let{textColor1:t,dividerColor:n,fontWeightStrong:r}=e;return{textColor:t,color:n,fontWeight:r}}var v={name:`Divider`,common:s,self:_},y=l(`divider`,`
 position: relative;
 display: flex;
 width: 100%;
 box-sizing: border-box;
 font-size: 16px;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
`,[t(`vertical`,`
 margin-top: 24px;
 margin-bottom: 24px;
 `,[t(`no-title`,`
 display: flex;
 align-items: center;
 `)]),o(`title`,`
 display: flex;
 align-items: center;
 margin-left: 12px;
 margin-right: 12px;
 white-space: nowrap;
 font-weight: var(--n-font-weight);
 `),a(`title-position-left`,[o(`line`,[a(`left`,{width:`28px`})])]),a(`title-position-right`,[o(`line`,[a(`right`,{width:`28px`})])]),a(`dashed`,[o(`line`,`
 background-color: #0000;
 height: 0px;
 width: 100%;
 border-style: dashed;
 border-width: 1px 0 0;
 `)]),a(`vertical`,`
 display: inline-block;
 height: 1em;
 margin: 0 8px;
 vertical-align: middle;
 width: 1px;
 `),o(`line`,`
 border: none;
 transition: background-color .3s var(--n-bezier), border-color .3s var(--n-bezier);
 height: 1px;
 width: 100%;
 margin: 0;
 `),t(`dashed`,[o(`line`,{backgroundColor:`var(--n-color)`})]),a(`dashed`,[o(`line`,{borderColor:`var(--n-color)`})]),a(`vertical`,{backgroundColor:`var(--n-color)`})]),b={...e.props,titlePlacement:{type:String,default:`center`},dashed:Boolean,vertical:Boolean},x=u({name:`Divider`,props:b,setup(t){let{mergedClsPrefixRef:n,inlineThemeDisabled:r}=i(t),a=e(`Divider`,`-divider`,y,v,t,n),o=h(()=>{let{common:{cubicBezierEaseInOut:e},self:{color:t,textColor:n,fontWeight:r}}=a.value;return{"--n-bezier":e,"--n-color":t,"--n-text-color":n,"--n-font-weight":r}}),s=r?c(`divider`,void 0,o,t):void 0;return{mergedClsPrefix:n,cssVars:r?void 0:o,themeClass:s?.themeClass,onRender:s?.onRender}},render(){let{$slots:e,titlePlacement:t,vertical:i,dashed:a,cssVars:o,mergedClsPrefix:s}=this;return this.onRender?.(),d(),f(`div`,{role:`separator`,class:n([`${s}-divider`,this.themeClass,{[`${s}-divider--vertical`]:i,[`${s}-divider--no-title`]:!e.default,[`${s}-divider--dashed`]:a,[`${s}-divider--title-position-${t}`]:e.default&&t}]),style:m(o)},[i?r(()=>null):(d(),f(`div`,{key:0,class:n(`${s}-divider__line ${s}-divider__line--left`)},null,2)),!i&&e.default?(d(),f(p,{key:2},[g(`div`,{class:n(`${s}-divider__title`)},[r(()=>this.$slots.default?.())],2),g(`div`,{class:n(`${s}-divider__line ${s}-divider__line--right`)},null,2)],64)):r(()=>null)],6)}});export{b as n,x as t};
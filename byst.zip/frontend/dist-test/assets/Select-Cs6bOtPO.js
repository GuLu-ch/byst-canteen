import{$ as e,At as t,Ct as n,Dt as r,Et as i,Ft as a,G as o,H as s,J as c,M as l,Ot as u,R as d,T as f,Tt as p,V as m,W as h,Y as g,Z as _,_r as v,a as y,an as b,cn as x,ct as ee,dn as S,en as te,fr as C,gn as ne,gr as w,hr as T,in as re,jt as E,kt as ie,ln as D,lt as ae,nn as O,ot as k,pn as oe,pr as A,pt as j,q as M,rt as N,sn as P,st as F,tt as se,v as I,vr as L,w as ce,wt as R,y as le}from"./Skeleton-DVjzRZkO.js";import{A as z,E as B,G as V,H,I as ue,M as U,N as de,Q as fe,S as W,T as G,U as pe,X as me,Y as he,at as K,b as q,ct as J,k as ge,m as Y,o as _e,pt as ve,u as ye,v as X,w as be,y as Z,z as xe}from"./vue-vendor-BGcTsaF8.js";import{d as Se,g as Ce,h as we,o as Te,t as Ee}from"./Tag-BOvzHE0n.js";var De={iconSizeTiny:`28px`,iconSizeSmall:`34px`,iconSizeMedium:`40px`,iconSizeLarge:`46px`,iconSizeHuge:`52px`};function Oe(e){let{textColorDisabled:t,iconColor:n,textColor2:r,fontSizeTiny:i,fontSizeSmall:a,fontSizeMedium:o,fontSizeLarge:s,fontSizeHuge:c}=e;return{...De,fontSizeTiny:i,fontSizeSmall:a,fontSizeMedium:o,fontSizeLarge:s,fontSizeHuge:c,textColor:t,iconColor:n,extraTextColor:r}}var ke={name:`Empty`,common:E,self:Oe},Ae=B({name:`Empty`,render(){return(()=>{let e=P(`15c1a247ae156450`);return e[0]||=Z(`svg`,{viewBox:`0 0 28 28`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`},[Z(`path`,{d:`M26 7.5C26 11.0899 23.0899 14 19.5 14C15.9101 14 13 11.0899 13 7.5C13 3.91015 15.9101 1 19.5 1C23.0899 1 26 3.91015 26 7.5ZM16.8536 4.14645C16.6583 3.95118 16.3417 3.95118 16.1464 4.14645C15.9512 4.34171 15.9512 4.65829 16.1464 4.85355L18.7929 7.5L16.1464 10.1464C15.9512 10.3417 15.9512 10.6583 16.1464 10.8536C16.3417 11.0488 16.6583 11.0488 16.8536 10.8536L19.5 8.20711L22.1464 10.8536C22.3417 11.0488 22.6583 11.0488 22.8536 10.8536C23.0488 10.6583 23.0488 10.3417 22.8536 10.1464L20.2071 7.5L22.8536 4.85355C23.0488 4.65829 23.0488 4.34171 22.8536 4.14645C22.6583 3.95118 22.3417 3.95118 22.1464 4.14645L19.5 6.79289L16.8536 4.14645Z`,fill:`currentColor`}),Z(`path`,{d:`M25 22.75V12.5991C24.5572 13.0765 24.053 13.4961 23.5 13.8454V16H17.5L17.3982 16.0068C17.0322 16.0565 16.75 16.3703 16.75 16.75C16.75 18.2688 15.5188 19.5 14 19.5C12.4812 19.5 11.25 18.2688 11.25 16.75L11.2432 16.6482C11.1935 16.2822 10.8797 16 10.5 16H4.5V7.25C4.5 6.2835 5.2835 5.5 6.25 5.5H12.2696C12.4146 4.97463 12.6153 4.47237 12.865 4H6.25C4.45507 4 3 5.45507 3 7.25V22.75C3 24.5449 4.45507 26 6.25 26H21.75C23.5449 26 25 24.5449 25 22.75ZM4.5 22.75V17.5H9.81597L9.85751 17.7041C10.2905 19.5919 11.9808 21 14 21L14.215 20.9947C16.2095 20.8953 17.842 19.4209 18.184 17.5H23.5V22.75C23.5 23.7165 22.7165 24.5 21.75 24.5H6.25C5.2835 24.5 4.5 23.7165 4.5 22.75Z`,fill:`currentColor`})],-1)})()}}),je=A(`empty`,`
 display: flex;
 flex-direction: column;
 align-items: center;
 font-size: var(--n-font-size);
`,[T(`icon`,`
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 font-size: var(--n-icon-size);
 line-height: var(--n-icon-size);
 color: var(--n-icon-color);
 transition:
 color .3s var(--n-bezier);
 `,[C(`+`,[T(`description`,`
 margin-top: 8px;
 `)])]),T(`description`,`
 transition: color .3s var(--n-bezier);
 color: var(--n-text-color);
 `),T(`extra`,`
 text-align: center;
 transition: color .3s var(--n-bezier);
 margin-top: 12px;
 color: var(--n-extra-text-color);
 `)]),Me={...r.props,description:String,showDescription:{type:Boolean,default:!0},showIcon:{type:Boolean,default:!0},size:{type:String,default:`medium`},renderIcon:Function},Ne=B({name:`Empty`,props:Me,slots:Object,setup(e){let{mergedClsPrefixRef:t,inlineThemeDisabled:n,mergedComponentPropsRef:i}=ne(e),a=r(`Empty`,`-empty`,je,ke,e,t),{localeRef:o}=u(`Empty`),s=X(()=>e.description??i?.value?.Empty?.description),c=X(()=>i?.value?.Empty?.renderIcon||(()=>(H(),q(Ae)))),l=X(()=>{let{size:t}=e,{common:{cubicBezierEaseInOut:n},self:{[L(`iconSize`,t)]:r,[L(`fontSize`,t)]:i,textColor:o,iconColor:s,extraTextColor:c}}=a.value;return{"--n-icon-size":r,"--n-font-size":i,"--n-bezier":n,"--n-text-color":o,"--n-icon-color":s,"--n-extra-text-color":c}}),d=n?ie(`empty`,X(()=>{let t=``,{size:n}=e;return t+=n[0],t}),l,e):void 0;return{mergedClsPrefix:t,mergedRenderIcon:c,localizedDescription:X(()=>s.value||o.value.description),cssVars:n?void 0:l,themeClass:d?.themeClass,onRender:d?.onRender}},render(){let{$slots:e,mergedClsPrefix:t,onRender:n}=this;return n?.(),H(),W(`div`,{class:x([`${t}-empty`,this.themeClass]),style:ve(this.cssVars)},[this.showIcon?(H(),W(`div`,{key:0,class:x(`${t}-empty__icon`)},[e.icon?(H(),W(Y,{key:0},[S(()=>e.icon())],64)):(H(),q(p,{key:1,clsPrefix:t},{default:this.mergedRenderIcon},1032,[`clsPrefix`]))],2)):S(()=>null),this.showDescription?(H(),W(`div`,{key:2,class:x(`${t}-empty__description`)},[e.default?(H(),W(Y,{key:0},[S(()=>e.default())],64)):(H(),W(Y,{key:1},[S(()=>this.localizedDescription)],64))],2)):S(()=>null),e.extra?(H(),W(`div`,{key:4,class:x(`${t}-empty__extra`)},[S(()=>e.extra())],2)):S(()=>null)],6)}}),Pe={height:`calc(var(--n-option-height) * 7.6)`,paddingTiny:`4px 0`,paddingSmall:`4px 0`,paddingMedium:`4px 0`,paddingLarge:`4px 0`,paddingHuge:`4px 0`,optionPaddingTiny:`0 12px`,optionPaddingSmall:`0 12px`,optionPaddingMedium:`0 12px`,optionPaddingLarge:`0 12px`,optionPaddingHuge:`0 12px`,loadingSize:`18px`};function Fe(e){let{borderRadius:t,popoverColor:n,textColor3:r,dividerColor:i,textColor2:a,primaryColorPressed:o,textColorDisabled:s,primaryColor:c,opacityDisabled:l,hoverColor:u,fontSizeTiny:d,fontSizeSmall:f,fontSizeMedium:p,fontSizeLarge:m,fontSizeHuge:h,heightTiny:g,heightSmall:_,heightMedium:v,heightLarge:y,heightHuge:b}=e;return{...Pe,optionFontSizeTiny:d,optionFontSizeSmall:f,optionFontSizeMedium:p,optionFontSizeLarge:m,optionFontSizeHuge:h,optionHeightTiny:g,optionHeightSmall:_,optionHeightMedium:v,optionHeightLarge:y,optionHeightHuge:b,borderRadius:t,color:n,groupHeaderTextColor:r,actionDividerColor:i,optionTextColor:a,optionTextColorPressed:o,optionTextColorDisabled:s,optionTextColorActive:c,optionOpacityDisabled:l,optionCheckColor:c,optionColorPending:u,optionColorActive:`rgba(0, 0, 0, 0)`,optionColorActivePending:u,actionTextColor:a,loadingColor:c}}var Ie=i({name:`InternalSelectMenu`,common:E,peers:{Scrollbar:t,Empty:ke},self:Fe}),Q=`v-hidden`,Le=h(`[v-hidden]`,{display:`none!important`}),Re=B({name:`Overflow`,props:{getCounter:Function,getTail:Function,updateCounter:Function,onUpdateCount:Function,onUpdateOverflow:Function},setup(e,{slots:t}){let n=K(null),r=K(null);function i(i){let{value:a}=n,{getCounter:o,getTail:s}=e,c;if(c=o===void 0?r.value:o(),!a||!c)return;c.hasAttribute(Q)&&c.removeAttribute(Q);let{children:l}=a;if(i.showAllItemsBeforeCalculate)for(let e of l)e.hasAttribute(Q)&&e.removeAttribute(Q);let u=a.offsetWidth,d=[],f=t.tail?s?.():null,p=f?f.offsetWidth:0,m=!1,h=a.children.length-+!!t.tail;for(let t=0;t<h-1;++t){if(t<0)continue;let n=l[t];if(m){n.hasAttribute(Q)||n.setAttribute(Q,``);continue}n.hasAttribute(Q)&&n.removeAttribute(Q);let r=n.offsetWidth;if(p+=r,d[t]=r,p>u){let{updateCounter:n}=e;for(let r=t;r>=0;--r){let i=h-1-r;n===void 0?c.textContent=`${i}`:n(i);let a=c.offsetWidth;if(p-=d[r],p+a<=u||r===0){m=!0,t=r-1,f&&(t===-1?(f.style.maxWidth=`${u-a}px`,f.style.boxSizing=`border-box`):f.style.maxWidth=``);let{onUpdateCount:n}=e;n&&n(i);break}}}}let{onUpdateOverflow:g}=e;m?g!==void 0&&g(!0):(g!==void 0&&g(!1),c.setAttribute(Q,``))}let a=oe();return Le.mount({id:`vueuc/overflow`,head:!0,anchorMetaName:o,ssr:a}),xe(()=>i({showAllItemsBeforeCalculate:!1})),{selfRef:n,counterRef:r,sync:i}},render(){let{$slots:e}=this;return de(()=>this.sync({showAllItemsBeforeCalculate:!1})),ge(`div`,{class:`v-overflow`,ref:`selfRef`},[V(e,`default`),e.counter?e.counter():ge(`span`,{style:{display:`inline-block`},ref:`counterRef`}),e.tail?e.tail():null])}}),ze={paddingSingle:`0 26px 0 12px`,paddingMultiple:`3px 26px 0 12px`,clearSize:`16px`,arrowSize:`16px`};function Be(e){switch(typeof e){case`string`:return e||void 0;case`number`:return String(e);default:return}}function Ve(e,t){t&&(xe(()=>{let{value:n}=e;n&&m.registerHandler(n,t)}),he(e,(e,t)=>{t&&m.unregisterHandler(t)},{deep:!1}),ue(()=>{let{value:t}=e;t&&m.unregisterHandler(t)}))}function $(e,...t){return typeof e==`function`?e(...t):typeof e==`string`?be(e):typeof e==`number`?be(String(e)):null}var He=B({name:`NBaseSelectGroupHeader`,props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(){let{renderLabelRef:e,renderOptionRef:t,labelFieldRef:n,nodePropsRef:r}=z(R);return{labelField:n,nodeProps:r,renderLabel:e,renderOption:t}},render(){let{clsPrefix:e,renderLabel:t,renderOption:n,nodeProps:r,tmNode:{rawNode:i}}=this,a=r?.(i),o=t?t(i,!1):$(i[this.labelField],i,!1),s=(H(),W(`div`,U(a,{class:[`${e}-base-select-group-header`,a?.class]}),[S(()=>o)],16));return i.render?i.render({node:s,option:i}):n?n({node:s,option:i,selected:!1}):s}});function Ue(e){let t=e.filter(e=>e!==void 0);if(t.length!==0)return t.length===1?t[0]:t=>{e.forEach(e=>{e&&e(t)})}}var We=B({name:`Checkmark`,render(){return(()=>{let e=P(`3c84eac8ae4e1f96`);return e[0]||=Z(`svg`,{xmlns:`http://www.w3.org/2000/svg`,viewBox:`0 0 16 16`},[Z(`g`,{fill:`none`},[Z(`path`,{d:`M14.046 3.486a.75.75 0 0 1-.032 1.06l-7.93 7.474a.85.85 0 0 1-1.188-.022l-2.68-2.72a.75.75 0 1 1 1.068-1.053l2.234 2.267l7.468-7.038a.75.75 0 0 1 1.06.032z`,fill:`currentColor`})])],-1)})()}}),Ge=[`onClick`,`onMouseenter`,`onMousemove`];function Ke(e,t){return H(),q(_e,{name:`fade-in-scale-up-transition`},{default:()=>e?(H(),q(p,{key:1,clsPrefix:t,class:x(`${t}-base-select-option__check`)},{default:()=>ge(We)},1032,[`clsPrefix`,`class`])):null},1024)}var qe=B({name:`NBaseSelectOption`,props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(e){let{valueRef:t,pendingTmNodeRef:n,multipleRef:r,valueSetRef:i,renderLabelRef:a,renderOptionRef:o,labelFieldRef:s,valueFieldRef:c,showCheckmarkRef:l,nodePropsRef:u,handleOptionClick:d,handleOptionMouseEnter:f}=z(R),p=j(()=>{let{value:t}=n;return t?e.tmNode.key===t.key:!1});function m(t){let{tmNode:n}=e;n.disabled||d(t,n)}function h(t){let{tmNode:n}=e;n.disabled||f(t,n)}function g(t){let{tmNode:n}=e,{value:r}=p;n.disabled||r||f(t,n)}return{multiple:r,isGrouped:j(()=>{let{tmNode:t}=e,{parent:n}=t;return n&&n.rawNode.type===`group`}),showCheckmark:l,nodeProps:u,isPending:p,isSelected:j(()=>{let{value:n}=t,{value:a}=r;if(n===null)return!1;let o=e.tmNode.rawNode[c.value];if(a){let{value:e}=i;return e.has(o)}return n===o}),labelField:s,renderLabel:a,renderOption:o,handleMouseMove:g,handleMouseEnter:h,handleClick:m}},render(){let{clsPrefix:e,tmNode:{rawNode:t},isSelected:n,isPending:r,isGrouped:i,showCheckmark:a,nodeProps:o,renderOption:s,renderLabel:c,handleClick:l,handleMouseEnter:u,handleMouseMove:d}=this,f=Ke(n,e),p=c?[c(t,n),a&&f]:[$(t[this.labelField],t,n),a&&f],m=o?.(t),h=(H(),W(`div`,U(m,{class:[`${e}-base-select-option`,t.class,m?.class,{[`${e}-base-select-option--disabled`]:t.disabled,[`${e}-base-select-option--selected`]:n,[`${e}-base-select-option--grouped`]:i,[`${e}-base-select-option--pending`]:r,[`${e}-base-select-option--show-checkmark`]:a}],style:[m?.style||``,t.style||``],onClick:Ue([l,m?.onClick]),onMouseenter:Ue([u,m?.onMouseenter]),onMousemove:Ue([d,m?.onMousemove])}),[Z(`div`,{class:x(`${e}-base-select-option__content`)},[S(()=>p)],2)],16,Ge));return t.render?t.render({node:h,option:t,selected:n}):s?s({node:h,option:t,selected:n}):h}}),Je=A(`base-select-menu`,`
 line-height: 1.5;
 outline: none;
 z-index: 0;
 position: relative;
 border-radius: var(--n-border-radius);
 transition:
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 background-color: var(--n-color);
`,[A(`scrollbar`,`
 max-height: var(--n-height);
 `),A(`virtual-list`,`
 max-height: var(--n-height);
 `),A(`base-select-option`,`
 min-height: var(--n-option-height);
 font-size: var(--n-option-font-size);
 display: flex;
 align-items: center;
 `,[T(`content`,`
 z-index: 1;
 white-space: nowrap;
 text-overflow: ellipsis;
 overflow: hidden;
 `)]),A(`base-select-group-header`,`
 min-height: var(--n-option-height);
 font-size: .93em;
 display: flex;
 align-items: center;
 `),A(`base-select-menu-option-wrapper`,`
 position: relative;
 width: 100%;
 `),T(`loading, empty`,`
 display: flex;
 padding: 12px 32px;
 flex: 1;
 justify-content: center;
 `),T(`loading`,`
 color: var(--n-loading-color);
 font-size: var(--n-loading-size);
 `),T(`header`,`
 padding: 8px var(--n-option-padding-left);
 font-size: var(--n-option-font-size);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-action-divider-color);
 color: var(--n-action-text-color);
 `),T(`action`,`
 padding: 8px var(--n-option-padding-left);
 font-size: var(--n-option-font-size);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 border-top: 1px solid var(--n-action-divider-color);
 color: var(--n-action-text-color);
 `),A(`base-select-group-header`,`
 position: relative;
 cursor: default;
 padding: var(--n-option-padding);
 color: var(--n-group-header-text-color);
 `),A(`base-select-option`,`
 cursor: pointer;
 position: relative;
 padding: var(--n-option-padding);
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 box-sizing: border-box;
 color: var(--n-option-text-color);
 opacity: 1;
 `,[w(`show-checkmark`,`
 padding-right: calc(var(--n-option-padding-right) + 20px);
 `),C(`&::before`,`
 content: "";
 position: absolute;
 left: 4px;
 right: 4px;
 top: 0;
 bottom: 0;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),C(`&:active`,`
 color: var(--n-option-text-color-pressed);
 `),w(`grouped`,`
 padding-left: calc(var(--n-option-padding-left) * 1.5);
 `),w(`pending`,[C(`&::before`,`
 background-color: var(--n-option-color-pending);
 `)]),w(`selected`,`
 color: var(--n-option-text-color-active);
 `,[C(`&::before`,`
 background-color: var(--n-option-color-active);
 `),w(`pending`,[C(`&::before`,`
 background-color: var(--n-option-color-active-pending);
 `)])]),w(`disabled`,`
 cursor: not-allowed;
 `,[v(`selected`,`
 color: var(--n-option-text-color-disabled);
 `),w(`selected`,`
 opacity: var(--n-option-opacity-disabled);
 `)]),T(`check`,`
 font-size: 16px;
 position: absolute;
 right: calc(var(--n-option-padding-right) - 4px);
 top: calc(50% - 7px);
 color: var(--n-option-check-color);
 transition: color .3s var(--n-bezier);
 `,[I({enterScale:`0.5`})])])]);function Ye(e){return Array.isArray(e)?e:[e]}var Xe={STOP:`STOP`};function Ze(e,t){let n=t(e);e.children!==void 0&&n!==Xe.STOP&&e.children.forEach(e=>Ze(e,t))}function Qe(e,t={}){let{preserveGroup:n=!1}=t,r=[],i=n?e=>{e.isLeaf||(r.push(e.key),a(e.children))}:e=>{e.isLeaf||(e.isGroup||r.push(e.key),a(e.children))};function a(e){e.forEach(i)}return a(e),r}function $e(e,t){let{isLeaf:n}=e;return n===void 0?!t(e):n}function et(e){return e.children}function tt(e){return e.key}function nt(){return!1}function rt(e,t){let{isLeaf:n}=e;return!(n===!1&&!Array.isArray(t(e)))}function it(e){return e.disabled===!0}function at(e,t){return e.isLeaf===!1&&!Array.isArray(t(e))}function ot(e){return e==null?[]:Array.isArray(e)?e:e.checkedKeys??[]}function st(e){return e==null||Array.isArray(e)?[]:e.indeterminateKeys??[]}function ct(e,t){let n=new Set(e);return t.forEach(e=>{n.has(e)||n.add(e)}),Array.from(n)}function lt(e,t){let n=new Set(e);return t.forEach(e=>{n.has(e)&&n.delete(e)}),Array.from(n)}function ut(e){return e?.type===`group`}function dt(e){let t=new Map;return e.forEach((e,n)=>{t.set(e.key,n)}),e=>t.get(e)??null}var ft=class extends Error{constructor(){super(),this.message=`SubtreeNotLoadedError: checking a subtree whose required nodes are not fully loaded.`}};function pt(e,t,n,r){return _t(t.concat(e),n,r,!1)}function mt(e,t){let n=new Set;return e.forEach(e=>{let r=t.treeNodeMap.get(e);if(r!==void 0){let e=r.parent;for(;e!==null&&!(e.disabled||n.has(e.key));)n.add(e.key),e=e.parent}}),n}function ht(e,t,n,r){let i=_t(t,n,r,!1),a=_t(e,n,r,!0),o=mt(e,n),s=[];return i.forEach(e=>{(a.has(e)||o.has(e))&&s.push(e)}),s.forEach(e=>i.delete(e)),i}function gt(e,t){let{checkedKeys:n,keysToCheck:r,keysToUncheck:i,indeterminateKeys:a,cascade:o,leafOnly:s,checkStrategy:c,allowNotLoaded:l}=e;if(!o)return r===void 0?i===void 0?{checkedKeys:Array.from(n),indeterminateKeys:Array.from(a)}:{checkedKeys:lt(n,i),indeterminateKeys:Array.from(a)}:{checkedKeys:ct(n,r),indeterminateKeys:Array.from(a)};let{levelTreeNodeMap:u}=t,d;d=i===void 0?r===void 0?_t(n,t,l,!1):pt(r,n,t,l):ht(i,n,t,l);let f=c===`parent`,p=c===`child`||s,m=d,h=new Set,g=Math.max.apply(null,Array.from(u.keys()));for(let e=g;e>=0;--e){let t=e===0,n=u.get(e);for(let e of n){if(e.isLeaf)continue;let{key:n,shallowLoaded:r}=e;if(p&&r&&e.children.forEach(e=>{!e.disabled&&!e.isLeaf&&e.shallowLoaded&&m.has(e.key)&&m.delete(e.key)}),e.disabled||!r)continue;let i=!0,a=!1,o=!0;for(let t of e.children){let e=t.key;if(!t.disabled){if(o&&=!1,m.has(e))a=!0;else if(h.has(e)){a=!0,i=!1;break}else if(i=!1,a)break}}i&&!o?(f&&e.children.forEach(e=>{!e.disabled&&m.has(e.key)&&m.delete(e.key)}),m.add(n)):a&&h.add(n),t&&p&&m.has(n)&&m.delete(n)}}return{checkedKeys:Array.from(m),indeterminateKeys:Array.from(h)}}function _t(e,t,n,r){let{treeNodeMap:i,getChildren:a}=t,o=new Set,s=new Set(e);return e.forEach(e=>{let t=i.get(e);t!==void 0&&Ze(t,e=>{if(e.disabled)return Xe.STOP;let{key:t}=e;if(!o.has(t)&&(o.add(t),s.add(t),at(e.rawNode,a))){if(r)return Xe.STOP;if(!n)throw new ft}})}),s}function vt(e,{includeGroup:t=!1,includeSelf:n=!0},r){let i=r.treeNodeMap,a=e==null?null:i.get(e)??null,o={keyPath:[],treeNodePath:[],treeNode:a};if(a?.ignored)return o.treeNode=null,o;for(;a;)a.ignored||!t&&a.isGroup||o.treeNodePath.push(a),a=a.parent;return o.treeNodePath.reverse(),n||o.treeNodePath.pop(),o.keyPath=o.treeNodePath.map(e=>e.key),o}function yt(e){if(e.length===0)return null;let t=e[0];return t.isGroup||t.ignored||t.disabled?t.getNext():t}function bt(e,t){let n=e.siblings,r=n.length,{index:i}=e;return t?n[(i+1)%r]:i===n.length-1?null:n[i+1]}function xt(e,t,{loop:n=!1,includeDisabled:r=!1}={}){let i=t===`prev`?St:bt,a={reverse:t===`prev`},o=!1,s=null;function c(t){if(t!==null){if(t===e){if(!o)o=!0;else if(!e.disabled&&!e.isGroup){s=e;return}}else if((!t.disabled||r)&&!t.ignored&&!t.isGroup){s=t;return}if(t.isGroup){let e=wt(t,a);e===null?c(i(t,n)):s=e}else{let e=i(t,!1);if(e!==null)c(e);else{let e=Ct(t);e?.isGroup?c(i(e,n)):n&&c(i(t,!0))}}}}return c(e),s}function St(e,t){let n=e.siblings,r=n.length,{index:i}=e;return t?n[(i-1+r)%r]:i===0?null:n[i-1]}function Ct(e){return e.parent}function wt(e,t={}){let{reverse:n=!1}=t,{children:r}=e;if(r){let{length:e}=r,i=n?e-1:0,a=n?-1:e,o=n?-1:1;for(let e=i;e!==a;e+=o){let n=r[e];if(!n.disabled&&!n.ignored){if(n.isGroup){let e=wt(n,t);if(e!==null)return e}else return n}}}return null}var Tt={getChild(){return this.ignored?null:wt(this)},getParent(){let{parent:e}=this;return e?.isGroup?e.getParent():e},getNext(e={}){return xt(this,`next`,e)},getPrev(e={}){return xt(this,`prev`,e)}};function Et(e,t){let n=t?new Set(t):void 0,r=[];function i(e){e.forEach(e=>{r.push(e),e.isLeaf||!e.children||e.ignored||(e.isGroup||n===void 0||n.has(e.key))&&i(e.children)})}return i(e),r}function Dt(e,t){let n=e.key;for(;t;){if(t.key===n)return!0;t=t.parent}return!1}function Ot(e,t,n,r,i,a=null,o=0){let s=[];return e.forEach((c,l)=>{var u;let d=Object.create(r);if(d.rawNode=c,d.siblings=s,d.level=o,d.index=l,d.isFirstChild=l===0,d.isLastChild=l+1===e.length,d.parent=a,!d.ignored){let e=i(c);Array.isArray(e)&&(d.children=Ot(e,t,n,r,i,d,o+1))}s.push(d),t.set(d.key,d),n.has(o)||n.set(o,[]),(u=n.get(o))==null||u.push(d)}),s}function kt(e,t={}){let n=new Map,r=new Map,{getDisabled:i=it,getIgnored:a=nt,getIsGroup:o=ut,getKey:s=tt}=t,c=t.getChildren??et,l=t.ignoreEmptyChildren?e=>{let t=c(e);return Array.isArray(t)?t.length?t:null:t}:c,u=Ot(e,n,r,Object.assign({get key(){return s(this.rawNode)},get disabled(){return i(this.rawNode)},get isGroup(){return o(this.rawNode)},get isLeaf(){return $e(this.rawNode,l)},get shallowLoaded(){return rt(this.rawNode,l)},get ignored(){return a(this.rawNode)},contains(e){return Dt(this,e)}},Tt),l);function d(e){if(e==null)return null;let t=n.get(e);return t&&!t.isGroup&&!t.ignored?t:null}function f(e){if(e==null)return null;let t=n.get(e);return t&&!t.ignored?t:null}function p(e,t){let n=f(e);return n?n.getPrev(t):null}function m(e,t){let n=f(e);return n?n.getNext(t):null}function h(e){let t=f(e);return t?t.getParent():null}function g(e){let t=f(e);return t?t.getChild():null}let _={treeNodes:u,treeNodeMap:n,levelTreeNodeMap:r,maxLevel:Math.max(...r.keys()),getChildren:l,getFlattenedNodes(e){return Et(u,e)},getNode:d,getPrev:p,getNext:m,getParent:h,getChild:g,getFirstAvailableNode(){return yt(u)},getPath(e,t={}){return vt(e,t,_)},getCheckedKeys(e,t={}){let{cascade:n=!0,leafOnly:r=!1,checkStrategy:i=`all`,allowNotLoaded:a=!1}=t;return gt({checkedKeys:ot(e),indeterminateKeys:st(e),cascade:n,leafOnly:r,checkStrategy:i,allowNotLoaded:a},_)},check(e,t,n={}){let{cascade:r=!0,leafOnly:i=!1,checkStrategy:a=`all`,allowNotLoaded:o=!1}=n;return gt({checkedKeys:ot(t),indeterminateKeys:st(t),keysToCheck:e==null?[]:Ye(e),cascade:r,leafOnly:i,checkStrategy:a,allowNotLoaded:o},_)},uncheck(e,t,n={}){let{cascade:r=!0,leafOnly:i=!1,checkStrategy:a=`all`,allowNotLoaded:o=!1}=n;return gt({checkedKeys:ot(t),indeterminateKeys:st(t),keysToUncheck:e==null?[]:Ye(e),cascade:r,leafOnly:i,checkStrategy:a,allowNotLoaded:o},_)},getNonLeafKeys(e={}){return Qe(u,e)}};return _}var At=[`tabindex`,`onFocusin`,`onFocusout`,`onKeyup`,`onKeydown`,`onMousedown`,`onMouseenter`,`onMouseleave`],jt=B({name:`InternalSelectMenu`,props:{...r.props,clsPrefix:{type:String,required:!0},scrollable:{type:Boolean,default:!0},treeMate:{type:Object,required:!0},multiple:Boolean,size:{type:String,default:`medium`},value:{type:[String,Number,Array],default:null},autoPending:Boolean,virtualScroll:{type:Boolean,default:!0},show:{type:Boolean,default:!0},labelField:{type:String,default:`label`},valueField:{type:String,default:`value`},loading:Boolean,focusable:Boolean,renderLabel:Function,renderOption:Function,nodeProps:Function,showCheckmark:{type:Boolean,default:!0},onMousedown:Function,onScroll:Function,onFocus:Function,onBlur:Function,onKeyup:Function,onKeydown:Function,onTabOut:Function,onMouseenter:Function,onMouseleave:Function,onResize:Function,resetMenuOnOptionsChange:{type:Boolean,default:!0},inlineThemeDisabled:Boolean,scrollbarProps:Object,onToggle:Function},setup(t){let{mergedClsPrefixRef:i,mergedRtlRef:a,mergedComponentPropsRef:o}=ne(t),s=e(`InternalSelectMenu`,a,i),c=r(`InternalSelectMenu`,`-internal-select-menu`,Je,Ie,t,J(t,`clsPrefix`)),l=K(null),u=K(null),d=K(null),f=X(()=>t.treeMate.getFlattenedNodes()),p=X(()=>dt(f.value)),m=K(null);function h(){let{treeMate:e}=t,n=null,{value:r}=t;r===null?n=e.getFirstAvailableNode():(n=t.multiple?e.getNode((r||[])[(r||[]).length-1]):e.getNode(r),(!n||n.disabled)&&(n=e.getFirstAvailableNode())),N(n||null)}function g(){let{value:e}=m;e&&!t.treeMate.getNode(e.key)&&(m.value=null)}let _;he(()=>t.show,e=>{e?_=he(()=>t.treeMate,()=>{t.resetMenuOnOptionsChange?(t.autoPending?h():g(),de(P)):g()},{immediate:!0}):_?.()},{immediate:!0}),ue(()=>{_?.()});let v=X(()=>te(c.value.self[L(`optionHeight`,t.size)])),y=X(()=>O(c.value.self[L(`padding`,t.size)])),x=X(()=>t.multiple&&Array.isArray(t.value)?new Set(t.value):new Set),ee=X(()=>{let e=f.value;return e&&e.length===0}),S=X(()=>o?.value?.Select?.renderEmpty);function C(e){let{onToggle:n}=t;n&&n(e)}function w(e){let{onScroll:n}=t;n&&n(e)}function T(e){d.value?.sync(),w(e)}function re(){d.value?.sync()}function E(){let{value:e}=m;return e||null}function D(e,t){t.disabled||N(t,!1)}function ae(e,t){t.disabled||C(t)}function k(e){b(e,`action`)||t.onKeyup?.(e)}function oe(e){b(e,`action`)||t.onKeydown?.(e)}function A(e){t.onMousedown?.(e),t.focusable||e.preventDefault()}function j(){let{value:e}=m;e&&N(e.getNext({loop:!0}),!0)}function M(){let{value:e}=m;e&&N(e.getPrev({loop:!0}),!0)}function N(e,t=!1){m.value=e,t&&P()}function P(){let e=m.value;if(!e)return;let n=p.value(e.key);n!==null&&(t.virtualScroll?u.value?.scrollTo({index:n}):d.value?.scrollTo({index:n,elSize:v.value}))}function F(e){l.value?.contains(e.target)&&t.onFocus?.(e)}function se(e){l.value?.contains(e.relatedTarget)||t.onBlur?.(e)}pe(R,{handleOptionMouseEnter:D,handleOptionClick:ae,valueSetRef:x,pendingTmNodeRef:m,nodePropsRef:J(t,`nodeProps`),showCheckmarkRef:J(t,`showCheckmark`),multipleRef:J(t,`multiple`),valueRef:J(t,`value`),renderLabelRef:J(t,`renderLabel`),renderOptionRef:J(t,`renderOption`),labelFieldRef:J(t,`labelField`),valueFieldRef:J(t,`valueField`)}),pe(n,l),xe(()=>{let{value:e}=d;e&&e.sync()});let I=X(()=>{let{size:e}=t,{common:{cubicBezierEaseInOut:n},self:{height:r,borderRadius:i,color:a,groupHeaderTextColor:o,actionDividerColor:s,optionTextColorPressed:l,optionTextColor:u,optionTextColorDisabled:d,optionTextColorActive:f,optionOpacityDisabled:p,optionCheckColor:m,actionTextColor:h,optionColorPending:g,optionColorActive:_,loadingColor:v,loadingSize:y,optionColorActivePending:b,[L(`optionFontSize`,e)]:x,[L(`optionHeight`,e)]:ee,[L(`optionPadding`,e)]:S}}=c.value;return{"--n-height":r,"--n-action-divider-color":s,"--n-action-text-color":h,"--n-bezier":n,"--n-border-radius":i,"--n-color":a,"--n-option-font-size":x,"--n-group-header-text-color":o,"--n-option-check-color":m,"--n-option-color-pending":g,"--n-option-color-active":_,"--n-option-color-active-pending":b,"--n-option-height":ee,"--n-option-opacity-disabled":p,"--n-option-text-color":u,"--n-option-text-color-active":f,"--n-option-text-color-disabled":d,"--n-option-text-color-pressed":l,"--n-option-padding":S,"--n-option-padding-left":O(S,`left`),"--n-option-padding-right":O(S,`right`),"--n-loading-color":v,"--n-loading-size":y}}),{inlineThemeDisabled:ce}=t,le=ce?ie(`internal-select-menu`,X(()=>t.size[0]),I,t):void 0,z={selfRef:l,next:j,prev:M,getPendingTmNode:E};return Ve(l,t.onResize),{mergedTheme:c,mergedClsPrefix:i,rtlEnabled:s,virtualListRef:u,scrollbarRef:d,itemSize:v,padding:y,flattenedNodes:f,empty:ee,mergedRenderEmpty:S,virtualListContainer(){let{value:e}=u;return e?.listElRef},virtualListContent(){let{value:e}=u;return e?.itemsElRef},doScroll:w,handleFocusin:F,handleFocusout:se,handleKeyUp:k,handleKeyDown:oe,handleMouseDown:A,handleVirtualListResize:re,handleVirtualListScroll:T,cssVars:ce?void 0:I,themeClass:le?.themeClass,onRender:le?.onRender,...z}},render(){let{$slots:e,virtualScroll:t,clsPrefix:n,mergedTheme:r,themeClass:i,onRender:a}=this;return a?.(),H(),W(`div`,{ref:`selfRef`,tabindex:this.focusable?0:-1,class:x([`${n}-base-select-menu`,`${n}-base-select-menu--${this.size}-size`,this.rtlEnabled&&`${n}-base-select-menu--rtl`,i,this.multiple&&`${n}-base-select-menu--multiple`]),style:ve(this.cssVars),onFocusin:this.handleFocusin,onFocusout:this.handleFocusout,onKeyup:this.handleKeyUp,onKeydown:this.handleKeyDown,onMousedown:this.handleMouseDown,onMouseenter:this.onMouseenter,onMouseleave:this.onMouseleave},[S(()=>N(e.header,e=>e&&(H(),W(`div`,{class:x(`${n}-base-select-menu__header`),"data-header":!0,key:`header`},[S(()=>e)],2)))),this.loading?(H(),W(`div`,{key:0,class:x(`${n}-base-select-menu__loading`)},[(H(),q(f,{clsPrefix:n,strokeWidth:20},null,8,[`clsPrefix`]))],2)):(H(),W(Y,{key:1},[this.empty?(H(),W(`div`,{key:1,class:x(`${n}-base-select-menu__empty`),"data-empty":!0},[S(()=>se(e.empty,()=>[this.mergedRenderEmpty?.()||(H(),q(Ne,{theme:r.peers.Empty,themeOverrides:r.peerOverrides.Empty,size:this.size},null,8,[`theme`,`themeOverrides`,`size`]))]))],2)):(H(),q(d,U({key:0,ref:`scrollbarRef`,theme:r.peers.Scrollbar,themeOverrides:r.peerOverrides.Scrollbar,scrollable:this.scrollable,container:t?this.virtualListContainer:void 0,content:t?this.virtualListContent:void 0,onScroll:t?void 0:this.doScroll},this.scrollbarProps),{default:()=>t?(H(),q(Se,{key:1,ref:`virtualListRef`,class:x(`${n}-virtual-list`),items:this.flattenedNodes,itemSize:this.itemSize,showScrollbar:!1,paddingTop:this.padding.top,paddingBottom:this.padding.bottom,onResize:this.handleVirtualListResize,onScroll:this.handleVirtualListScroll,itemResizable:!0},{default:({item:e})=>e.isGroup?(H(),q(He,{key:e.key,clsPrefix:n,tmNode:e},null,8,[`clsPrefix`,`tmNode`])):e.ignored?null:(H(),q(qe,{clsPrefix:n,key:e.key,tmNode:e},null,8,[`clsPrefix`,`tmNode`]))},1032,[`class`,`items`,`itemSize`,`paddingTop`,`paddingBottom`,`onResize`,`onScroll`])):(H(),W(`div`,{key:4,class:x(`${n}-base-select-menu-option-wrapper`),style:ve({paddingTop:this.padding.top,paddingBottom:this.padding.bottom})},[S(()=>this.flattenedNodes.map(e=>e.isGroup?(H(),q(He,{key:e.key,clsPrefix:n,tmNode:e},null,8,[`clsPrefix`,`tmNode`])):(H(),q(qe,{clsPrefix:n,key:e.key,tmNode:e},null,8,[`clsPrefix`,`tmNode`]))))],6))},1040,[`theme`,`themeOverrides`,`scrollable`,`container`,`content`,`onScroll`]))],64)),S(()=>N(e.action,e=>e&&[(H(),W(`div`,{class:x(`${n}-base-select-menu__action`),"data-action":!0,key:`action`},[S(()=>e)],2)),(H(),q(le,{onFocus:this.onTabOut,key:`focus-detector`},null,8,[`onFocus`]))]))],46,At)}});function Mt(e){return e.type===`group`}function Nt(e){return e.type===`ignored`}function Pt(e,t){try{return!!(1+t.toString().toLowerCase().indexOf(e.trim().toLowerCase()))}catch{return!1}}function Ft(e,t){return{getIsGroup:Mt,getIgnored:Nt,getKey(t){return Mt(t)?t.name||t.key||`key-required`:t[e]},getChildren(e){return e[t]}}}function It(e,t,n,r){if(!t)return e;function i(e){if(!Array.isArray(e))return[];let a=[];for(let o of e)if(Mt(o)){let e=i(o[r]);e.length&&a.push(Object.assign({},o,{[r]:e}))}else if(Nt(o))continue;else t(n,o)&&a.push(o);return a}return i(e)}function Lt(e,t,n){let r=new Map;return e.forEach(e=>{Mt(e)?e[n].forEach(e=>{r.set(e[t],e)}):r.set(e[t],e)}),r}function Rt(e){let{borderRadius:t,textColor2:n,textColorDisabled:r,inputColor:i,inputColorDisabled:o,primaryColor:s,primaryColorHover:c,warningColor:l,warningColorHover:u,errorColor:d,errorColorHover:f,borderColor:p,iconColor:m,iconColorDisabled:h,clearColor:g,clearColorHover:_,clearColorPressed:v,placeholderColor:y,placeholderColorDisabled:b,fontSizeTiny:x,fontSizeSmall:ee,fontSizeMedium:S,fontSizeLarge:te,heightTiny:C,heightSmall:ne,heightMedium:w,heightLarge:T,fontWeight:re}=e;return{...ze,fontSizeTiny:x,fontSizeSmall:ee,fontSizeMedium:S,fontSizeLarge:te,heightTiny:C,heightSmall:ne,heightMedium:w,heightLarge:T,borderRadius:t,fontWeight:re,textColor:n,textColorDisabled:r,placeholderColor:y,placeholderColorDisabled:b,color:i,colorDisabled:o,colorActive:i,border:`1px solid ${p}`,borderHover:`1px solid ${c}`,borderActive:`1px solid ${s}`,borderFocus:`1px solid ${c}`,boxShadowHover:`none`,boxShadowActive:`0 0 0 2px ${a(s,{alpha:.2})}`,boxShadowFocus:`0 0 0 2px ${a(s,{alpha:.2})}`,caretColor:s,arrowColor:m,arrowColorDisabled:h,loadingColor:s,borderWarning:`1px solid ${l}`,borderHoverWarning:`1px solid ${u}`,borderActiveWarning:`1px solid ${l}`,borderFocusWarning:`1px solid ${u}`,boxShadowHoverWarning:`none`,boxShadowActiveWarning:`0 0 0 2px ${a(l,{alpha:.2})}`,boxShadowFocusWarning:`0 0 0 2px ${a(l,{alpha:.2})}`,colorActiveWarning:i,caretColorWarning:l,borderError:`1px solid ${d}`,borderHoverError:`1px solid ${f}`,borderActiveError:`1px solid ${d}`,borderFocusError:`1px solid ${f}`,boxShadowHoverError:`none`,boxShadowActiveError:`0 0 0 2px ${a(d,{alpha:.2})}`,boxShadowFocusError:`0 0 0 2px ${a(d,{alpha:.2})}`,colorActiveError:i,caretColorError:d,clearColor:g,clearColorHover:_,clearColorPressed:v}}var zt=i({name:`InternalSelection`,common:E,peers:{Popover:Ce},self:Rt}),Bt=C([A(`base-selection`,`
 --n-padding-single: var(--n-padding-single-top) var(--n-padding-single-right) var(--n-padding-single-bottom) var(--n-padding-single-left);
 --n-padding-multiple: var(--n-padding-multiple-top) var(--n-padding-multiple-right) var(--n-padding-multiple-bottom) var(--n-padding-multiple-left);
 position: relative;
 z-index: auto;
 box-shadow: none;
 width: 100%;
 max-width: 100%;
 display: inline-block;
 vertical-align: bottom;
 border-radius: var(--n-border-radius);
 min-height: var(--n-height);
 line-height: 1.5;
 font-size: var(--n-font-size);
 `,[A(`base-loading`,`
 color: var(--n-loading-color);
 `),A(`base-selection-tags`,`min-height: var(--n-height);`),T(`border, state-border`,`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border: var(--n-border);
 border-radius: inherit;
 transition:
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),T(`state-border`,`
 z-index: 1;
 border-color: #0000;
 `),A(`base-suffix`,`
 cursor: pointer;
 position: absolute;
 top: 50%;
 transform: translateY(-50%);
 right: 10px;
 `,[T(`arrow`,`
 font-size: var(--n-arrow-size);
 color: var(--n-arrow-color);
 transition: color .3s var(--n-bezier);
 `)]),A(`base-selection-overlay`,`
 display: flex;
 align-items: center;
 white-space: nowrap;
 pointer-events: none;
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 left: 0;
 padding: var(--n-padding-single);
 transition: color .3s var(--n-bezier);
 `,[T(`wrapper`,`
 flex-basis: 0;
 flex-grow: 1;
 overflow: hidden;
 text-overflow: ellipsis;
 `)]),A(`base-selection-placeholder`,`
 color: var(--n-placeholder-color);
 `,[T(`inner`,`
 max-width: 100%;
 overflow: hidden;
 `)]),A(`base-selection-tags`,`
 cursor: pointer;
 outline: none;
 box-sizing: border-box;
 position: relative;
 z-index: auto;
 display: flex;
 padding: var(--n-padding-multiple);
 flex-wrap: wrap;
 align-items: center;
 width: 100%;
 vertical-align: bottom;
 background-color: var(--n-color);
 border-radius: inherit;
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),A(`base-selection-label`,`
 height: var(--n-height);
 display: inline-flex;
 width: 100%;
 vertical-align: bottom;
 cursor: pointer;
 outline: none;
 z-index: auto;
 box-sizing: border-box;
 position: relative;
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 border-radius: inherit;
 background-color: var(--n-color);
 align-items: center;
 `,[A(`base-selection-input`,`
 font-size: inherit;
 line-height: inherit;
 outline: none;
 cursor: pointer;
 box-sizing: border-box;
 border:none;
 width: 100%;
 padding: var(--n-padding-single);
 background-color: #0000;
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 caret-color: var(--n-caret-color);
 `,[T(`content`,`
 text-overflow: ellipsis;
 overflow: hidden;
 white-space: nowrap; 
 `)]),T(`render-label`,`
 color: var(--n-text-color);
 `)]),v(`disabled`,[C(`&:hover`,[T(`state-border`,`
 box-shadow: var(--n-box-shadow-hover);
 border: var(--n-border-hover);
 `)]),w(`focus`,[T(`state-border`,`
 box-shadow: var(--n-box-shadow-focus);
 border: var(--n-border-focus);
 `)]),w(`active`,[T(`state-border`,`
 box-shadow: var(--n-box-shadow-active);
 border: var(--n-border-active);
 `),A(`base-selection-label`,`background-color: var(--n-color-active);`),A(`base-selection-tags`,`background-color: var(--n-color-active);`)])]),w(`disabled`,`cursor: not-allowed;`,[T(`arrow`,`
 color: var(--n-arrow-color-disabled);
 `),A(`base-selection-label`,`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `,[A(`base-selection-input`,`
 cursor: not-allowed;
 color: var(--n-text-color-disabled);
 `),T(`render-label`,`
 color: var(--n-text-color-disabled);
 `)]),A(`base-selection-tags`,`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `),A(`base-selection-placeholder`,`
 cursor: not-allowed;
 color: var(--n-placeholder-color-disabled);
 `)]),A(`base-selection-input-tag`,`
 height: calc(var(--n-height) - 6px);
 line-height: calc(var(--n-height) - 6px);
 outline: none;
 display: none;
 position: relative;
 margin-bottom: 3px;
 max-width: 100%;
 vertical-align: bottom;
 `,[T(`input`,`
 font-size: inherit;
 font-family: inherit;
 min-width: 1px;
 padding: 0;
 background-color: #0000;
 outline: none;
 border: none;
 max-width: 100%;
 overflow: hidden;
 width: 1em;
 line-height: inherit;
 cursor: pointer;
 color: var(--n-text-color);
 caret-color: var(--n-caret-color);
 `),T(`mirror`,`
 position: absolute;
 left: 0;
 top: 0;
 white-space: pre;
 visibility: hidden;
 user-select: none;
 -webkit-user-select: none;
 opacity: 0;
 `)]),[`warning`,`error`].map(e=>w(`${e}-status`,[T(`state-border`,`border: var(--n-border-${e});`),v(`disabled`,[C(`&:hover`,[T(`state-border`,`
 box-shadow: var(--n-box-shadow-hover-${e});
 border: var(--n-border-hover-${e});
 `)]),w(`active`,[T(`state-border`,`
 box-shadow: var(--n-box-shadow-active-${e});
 border: var(--n-border-active-${e});
 `),A(`base-selection-label`,`background-color: var(--n-color-active-${e});`),A(`base-selection-tags`,`background-color: var(--n-color-active-${e});`)]),w(`focus`,[T(`state-border`,`
 box-shadow: var(--n-box-shadow-focus-${e});
 border: var(--n-border-focus-${e});
 `)])])]))]),A(`base-selection-popover`,`
 margin-bottom: -3px;
 display: flex;
 flex-wrap: wrap;
 margin-right: -8px;
 `),A(`base-selection-tag-wrapper`,`
 max-width: 100%;
 display: inline-flex;
 padding: 0 7px 3px 0;
 `,[C(`&:last-child`,`padding-right: 0;`),A(`tag`,`
 font-size: 14px;
 max-width: 100%;
 `,[T(`content`,`
 line-height: 1.25;
 text-overflow: ellipsis;
 overflow: hidden;
 `)])])]),Vt=[`disabled`,`value`,`autofocus`,`onBlur`,`onFocus`,`onKeydown`,`onInput`,`onCompositionstart`,`onCompositionend`],Ht=[`tabindex`],Ut=[`title`],Wt=[`value`,`readonly`,`disabled`,`autofocus`,`onFocus`,`onBlur`,`onInput`,`onCompositionstart`,`onCompositionend`],Gt=[`tabindex`],Kt=[`onClick`,`onMouseenter`,`onMouseleave`,`onKeydown`,`onFocusin`,`onFocusout`,`onMousedown`],qt=B({name:`InternalSelection`,props:{...r.props,clsPrefix:{type:String,required:!0},bordered:{type:Boolean,default:void 0},active:Boolean,pattern:{type:String,default:``},placeholder:String,selectedOption:{type:Object,default:null},selectedOptions:{type:Array,default:null},labelField:{type:String,default:`label`},valueField:{type:String,default:`value`},multiple:Boolean,filterable:Boolean,clearable:Boolean,disabled:Boolean,size:{type:String,default:`medium`},loading:Boolean,autofocus:Boolean,showArrow:{type:Boolean,default:!0},inputProps:Object,focused:Boolean,renderTag:Function,onKeydown:Function,onClick:Function,onBlur:Function,onFocus:Function,onDeleteOption:Function,maxTagCount:[String,Number],ellipsisTagPopoverProps:Object,onClear:Function,onPatternInput:Function,onPatternFocus:Function,onPatternBlur:Function,renderLabel:Function,status:String,inlineThemeDisabled:Boolean,ignoreComposition:{type:Boolean,default:!0},onResize:Function},setup(t){let{mergedClsPrefixRef:n,mergedRtlRef:i}=ne(t),a=e(`InternalSelection`,i,n),o=K(null),s=K(null),c=K(null),l=K(null),u=K(null),d=K(null),f=K(null),p=K(null),m=K(null),h=K(null),g=K(!1),_=K(!1),v=K(!1),y=r(`InternalSelection`,`-internal-selection`,Bt,zt,t,J(t,`clsPrefix`)),b=X(()=>t.clearable&&!t.disabled&&(v.value||t.active)),x=X(()=>t.selectedOption?t.renderTag?t.renderTag({option:t.selectedOption,handleClose:()=>{}}):t.renderLabel?t.renderLabel(t.selectedOption,!0):$(t.selectedOption[t.labelField],t.selectedOption,!0):t.placeholder),ee=X(()=>{let e=t.selectedOption;if(e)return e[t.labelField]}),S=X(()=>t.multiple?!!(Array.isArray(t.selectedOptions)&&t.selectedOptions.length):t.selectedOption!==null);function te(){let{value:e}=o;if(e){let{value:n}=s;n&&(n.style.width=`${e.offsetWidth}px`,t.maxTagCount!==`responsive`&&m.value?.sync({showAllItemsBeforeCalculate:!1}))}}function C(){let{value:e}=h;e&&(e.style.display=`none`)}function w(){let{value:e}=h;e&&(e.style.display=`inline-block`)}he(J(t,`active`),e=>{e||C()}),he(J(t,`pattern`),()=>{t.multiple&&de(te)});function T(e){let{onFocus:n}=t;n&&n(e)}function re(e){let{onBlur:n}=t;n&&n(e)}function E(e){let{onDeleteOption:n}=t;n&&n(e)}function D(e){let{onClear:n}=t;n&&n(e)}function ae(e){let{onPatternInput:n}=t;n&&n(e)}function k(e){e.relatedTarget&&c.value?.contains(e.relatedTarget)||T(e)}function oe(e){c.value?.contains(e.relatedTarget)||re(e)}function A(e){D(e)}function j(){v.value=!0}function M(){v.value=!1}function N(e){t.active&&t.filterable&&e.target!==s.value&&e.preventDefault()}function P(e){E(e)}let F=K(!1);function se(e){if(e.key===`Backspace`&&!F.value&&!t.pattern.length){let{selectedOptions:e}=t;e?.length&&P(e[e.length-1])}}let I=null;function ce(e){let{value:n}=o;n&&(n.textContent=e.target.value,te()),t.ignoreComposition&&F.value?I=e:ae(e)}function R(){F.value=!0}function le(){F.value=!1,t.ignoreComposition&&ae(I),I=null}function z(e){_.value=!0,t.onPatternFocus?.(e)}function B(e){_.value=!1,t.onPatternBlur?.(e)}function V(){if(t.filterable)_.value=!1,d.value?.blur(),s.value?.blur();else if(t.multiple){let{value:e}=l;e?.blur()}else{let{value:e}=u;e?.blur()}}function H(){t.filterable?(_.value=!1,d.value?.focus()):t.multiple?l.value?.focus():u.value?.focus()}function ue(){let{value:e}=s;e&&(w(),e.focus())}function U(){let{value:e}=s;e&&e.blur()}function fe(e){let{value:t}=f;t&&t.setTextContent(`+${e}`)}function W(){let{value:e}=p;return e}function G(){return s.value}let pe=null;function q(){pe!==null&&window.clearTimeout(pe)}function ge(){t.active||(q(),pe=window.setTimeout(()=>{S.value&&(g.value=!0)},100))}function Y(){q()}function _e(e){e||(q(),g.value=!1)}he(S,e=>{e||(g.value=!1)}),xe(()=>{me(()=>{let e=d.value;e&&(t.disabled?e.removeAttribute(`tabindex`):e.tabIndex=_.value?-1:0)})}),Ve(c,t.onResize);let{inlineThemeDisabled:ve}=t,ye=X(()=>{let{size:e}=t,{common:{cubicBezierEaseInOut:n},self:{fontWeight:r,borderRadius:i,color:a,placeholderColor:o,textColor:s,paddingSingle:c,paddingMultiple:l,caretColor:u,colorDisabled:d,textColorDisabled:f,placeholderColorDisabled:p,colorActive:m,boxShadowFocus:h,boxShadowActive:g,boxShadowHover:_,border:v,borderFocus:b,borderHover:x,borderActive:ee,arrowColor:S,arrowColorDisabled:te,loadingColor:C,colorActiveWarning:ne,boxShadowFocusWarning:w,boxShadowActiveWarning:T,boxShadowHoverWarning:re,borderWarning:E,borderFocusWarning:ie,borderHoverWarning:D,borderActiveWarning:ae,colorActiveError:k,boxShadowFocusError:oe,boxShadowActiveError:A,boxShadowHoverError:j,borderError:M,borderFocusError:N,borderHoverError:P,borderActiveError:F,clearColor:se,clearColorHover:I,clearColorPressed:ce,clearSize:R,arrowSize:le,[L(`height`,e)]:z,[L(`fontSize`,e)]:B}}=y.value,V=O(c),H=O(l);return{"--n-bezier":n,"--n-border":v,"--n-border-active":ee,"--n-border-focus":b,"--n-border-hover":x,"--n-border-radius":i,"--n-box-shadow-active":g,"--n-box-shadow-focus":h,"--n-box-shadow-hover":_,"--n-caret-color":u,"--n-color":a,"--n-color-active":m,"--n-color-disabled":d,"--n-font-size":B,"--n-height":z,"--n-padding-single-top":V.top,"--n-padding-multiple-top":H.top,"--n-padding-single-right":V.right,"--n-padding-multiple-right":H.right,"--n-padding-single-left":V.left,"--n-padding-multiple-left":H.left,"--n-padding-single-bottom":V.bottom,"--n-padding-multiple-bottom":H.bottom,"--n-placeholder-color":o,"--n-placeholder-color-disabled":p,"--n-text-color":s,"--n-text-color-disabled":f,"--n-arrow-color":S,"--n-arrow-color-disabled":te,"--n-loading-color":C,"--n-color-active-warning":ne,"--n-box-shadow-focus-warning":w,"--n-box-shadow-active-warning":T,"--n-box-shadow-hover-warning":re,"--n-border-warning":E,"--n-border-focus-warning":ie,"--n-border-hover-warning":D,"--n-border-active-warning":ae,"--n-color-active-error":k,"--n-box-shadow-focus-error":oe,"--n-box-shadow-active-error":A,"--n-box-shadow-hover-error":j,"--n-border-error":M,"--n-border-focus-error":N,"--n-border-hover-error":P,"--n-border-active-error":F,"--n-clear-size":R,"--n-clear-color":se,"--n-clear-color-hover":I,"--n-clear-color-pressed":ce,"--n-arrow-size":le,"--n-font-weight":r}}),be=ve?ie(`internal-selection`,X(()=>t.size[0]),ye,t):void 0;return{mergedTheme:y,mergedClearable:b,mergedClsPrefix:n,rtlEnabled:a,patternInputFocused:_,filterablePlaceholder:x,label:ee,selected:S,showTagsPanel:g,isComposing:F,counterRef:f,counterWrapperRef:p,patternInputMirrorRef:o,patternInputRef:s,selfRef:c,multipleElRef:l,singleElRef:u,patternInputWrapperRef:d,overflowRef:m,inputTagElRef:h,handleMouseDown:N,handleFocusin:k,handleClear:A,handleMouseEnter:j,handleMouseLeave:M,handleDeleteOption:P,handlePatternKeyDown:se,handlePatternInputInput:ce,handlePatternInputBlur:B,handlePatternInputFocus:z,handleMouseEnterCounter:ge,handleMouseLeaveCounter:Y,handleFocusout:oe,handleCompositionEnd:le,handleCompositionStart:R,onPopoverUpdateShow:_e,focus:H,focusInput:ue,blur:V,blurInput:U,updateCounter:fe,getCounter:W,getTail:G,renderLabel:t.renderLabel,cssVars:ve?void 0:ye,themeClass:be?.themeClass,onRender:be?.onRender}},render(){let{status:e,multiple:t,size:n,disabled:r,filterable:i,maxTagCount:a,bordered:o,clsPrefix:s,ellipsisTagPopoverProps:c,onRender:l,renderTag:u,renderLabel:d}=this;l?.();let f=a===`responsive`,p=typeof a==`number`,m=f||p,h=(H(),q(_,null,{default:()=>(H(),q(ce,{clsPrefix:s,loading:this.loading,showArrow:this.showArrow,showClear:this.mergedClearable&&this.selected,onClear:this.handleClear},{default:()=>this.$slots.arrow?.()},1032,[`clsPrefix`,`loading`,`showArrow`,`showClear`,`onClear`]))},1024)),g;if(t){let{labelField:e}=this,t=t=>(H(),W(`div`,{class:x(`${s}-base-selection-tag-wrapper`),key:t.value},[u?(H(),W(Y,{key:0},[S(()=>u({option:t,handleClose:()=>{this.handleDeleteOption(t)}}))],64)):(H(),q(Ee,{key:1,size:n,closable:!t.disabled,disabled:r,onClose:()=>{this.handleDeleteOption(t)},internalCloseIsButtonTag:!1,internalCloseFocusable:!1},{default:()=>d?d(t,!0):$(t[e],t,!0)},1032,[`size`,`closable`,`disabled`,`onClose`]))],2)),o=()=>(p?this.selectedOptions.slice(0,a):this.selectedOptions).map(t),l=i?(H(),W(`div`,{class:x(`${s}-base-selection-input-tag`),ref:`inputTagElRef`,key:`__input-tag__`},[Z(`input`,U(this.inputProps,{ref:`patternInputRef`,tabindex:-1,disabled:r,value:this.pattern,autofocus:this.autofocus,class:`${s}-base-selection-input-tag__input`,onBlur:this.handlePatternInputBlur,onFocus:this.handlePatternInputFocus,onKeydown:this.handlePatternKeyDown,onInput:this.handlePatternInputInput,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd}),null,16,Vt),Z(`span`,{ref:`patternInputMirrorRef`,class:x(`${s}-base-selection-input-tag__mirror`)},[S(()=>this.pattern)],2)],2)):null,_=f?()=>(H(),W(`div`,{class:x(`${s}-base-selection-tag-wrapper`),ref:`counterWrapperRef`},[(H(),q(Ee,{size:n,ref:`counterRef`,onMouseenter:this.handleMouseEnterCounter,onMouseleave:this.handleMouseLeaveCounter,disabled:r},null,8,[`size`,`onMouseenter`,`onMouseleave`,`disabled`]))],2)):void 0,v;if(p){let e=this.selectedOptions.length-a;e>0&&(v=(t=>(H(),W(`div`,{class:x(`${s}-base-selection-tag-wrapper`),key:`__counter__`},[(H(),q(Ee,{size:n,ref:`counterRef`,onMouseenter:this.handleMouseEnterCounter,disabled:r},{default:()=>`+${e}`},1032,[`size`,`onMouseenter`,`disabled`]))],2)))(v))}let y=f?i?(H(),q(Re,{key:3,ref:`overflowRef`,updateCounter:this.updateCounter,getCounter:this.getCounter,getTail:this.getTail,style:{width:`100%`,display:`flex`,overflow:`hidden`}},{default:o,counter:_,tail:()=>l},1032,[`updateCounter`,`getCounter`,`getTail`])):(H(),q(Re,{key:4,ref:`overflowRef`,updateCounter:this.updateCounter,getCounter:this.getCounter,style:{width:`100%`,display:`flex`,overflow:`hidden`}},{default:o,counter:_},1032,[`updateCounter`,`getCounter`])):p&&v?o().concat(v):o(),b=m?()=>(H(),W(`div`,{class:x(`${s}-base-selection-popover`)},[f?(H(),W(Y,{key:0},[S(()=>o())],64)):(H(),W(Y,{key:1},[S(()=>this.selectedOptions.map(t))],64))],2)):void 0,ee=m?{show:this.showTagsPanel,trigger:`hover`,overlap:!0,placement:`top`,width:`trigger`,onUpdateShow:this.onPopoverUpdateShow,theme:this.mergedTheme.peers.Popover,themeOverrides:this.mergedTheme.peerOverrides.Popover,...c}:null,te=!this.selected&&(!this.active||!this.pattern&&!this.isComposing)?(H(),W(`div`,{key:5,class:x(`${s}-base-selection-placeholder ${s}-base-selection-overlay`)},[Z(`div`,{class:x(`${s}-base-selection-placeholder__inner`)},[S(()=>this.placeholder)],2)],2)):null,C=i?(H(),W(`div`,{key:6,ref:`patternInputWrapperRef`,class:x(`${s}-base-selection-tags`)},[S(()=>y),f?S(()=>null):(H(),W(Y,{key:1},[S(()=>l)],64)),S(()=>h)],2)):(H(),W(`div`,{key:7,ref:`multipleElRef`,class:x(`${s}-base-selection-tags`),tabindex:r?void 0:0},[S(()=>y),S(()=>h)],10,Ht));g=(e=>(H(),W(Y,{key:8},[m?(H(),q(Te,U({key:0},ee,{scrollable:!0,style:`max-height: calc(var(--v-target-height) * 6.6);`}),{trigger:()=>C,default:b},1040)):(H(),W(Y,{key:1},[S(()=>C)],64)),S(()=>te)],64)))(g)}else if(i){let e=this.pattern||this.isComposing,t=this.active?!e:!this.selected,n=!this.active&&this.selected;g=(e=>(H(),W(`div`,{key:9,ref:`patternInputWrapperRef`,class:x(`${s}-base-selection-label`),title:this.patternInputFocused?void 0:Be(this.label)},[Z(`input`,U(this.inputProps,{ref:`patternInputRef`,class:`${s}-base-selection-input`,value:this.active?this.pattern:``,placeholder:``,readonly:r,disabled:r,tabindex:-1,autofocus:this.autofocus,onFocus:this.handlePatternInputFocus,onBlur:this.handlePatternInputBlur,onInput:this.handlePatternInputInput,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd}),null,16,Wt),n?(H(),W(`div`,{class:x(`${s}-base-selection-label__render-label ${s}-base-selection-overlay`),key:`input`},[Z(`div`,{class:x(`${s}-base-selection-overlay__wrapper`)},[u?(H(),W(Y,{key:0},[S(()=>u({option:this.selectedOption,handleClose:()=>{}}))],64)):(H(),W(Y,{key:1},[d?(H(),W(Y,{key:0},[S(()=>d(this.selectedOption,!0))],64)):(H(),W(Y,{key:1},[S(()=>$(this.label,this.selectedOption,!0))],64))],64))],2)],2)):S(()=>null),t?(H(),W(`div`,{class:x(`${s}-base-selection-placeholder ${s}-base-selection-overlay`),key:`placeholder`},[Z(`div`,{class:x(`${s}-base-selection-overlay__wrapper`)},[S(()=>this.filterablePlaceholder)],2)],2)):S(()=>null),S(()=>h)],10,Ut)))(g)}else g=(e=>(H(),W(`div`,{key:10,ref:`singleElRef`,class:x(`${s}-base-selection-label`),tabindex:this.disabled?void 0:0},[this.label===void 0?(H(),W(`div`,{class:x(`${s}-base-selection-placeholder ${s}-base-selection-overlay`),key:`placeholder`},[Z(`div`,{class:x(`${s}-base-selection-placeholder__inner`)},[S(()=>this.placeholder)],2)],2)):(H(),W(`div`,{class:x(`${s}-base-selection-input`),title:Be(this.label),key:`input`},[Z(`div`,{class:x(`${s}-base-selection-input__content`)},[u?(H(),W(Y,{key:0},[S(()=>u({option:this.selectedOption,handleClose:()=>{}}))],64)):(H(),W(Y,{key:1},[d?(H(),W(Y,{key:0},[S(()=>d(this.selectedOption,!0))],64)):(H(),W(Y,{key:1},[S(()=>$(this.label,this.selectedOption,!0))],64))],64))],2)],10,[`title`])),S(()=>h)],10,Gt)))(g);return H(),W(`div`,{ref:`selfRef`,class:x([`${s}-base-selection`,this.rtlEnabled&&`${s}-base-selection--rtl`,this.themeClass,e&&`${s}-base-selection--${e}-status`,{[`${s}-base-selection--active`]:this.active,[`${s}-base-selection--selected`]:this.selected||this.active&&this.pattern,[`${s}-base-selection--disabled`]:this.disabled,[`${s}-base-selection--multiple`]:this.multiple,[`${s}-base-selection--focus`]:this.focused}]),style:ve(this.cssVars),onClick:this.onClick,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onKeydown:this.onKeydown,onFocusin:this.handleFocusin,onFocusout:this.handleFocusout,onMousedown:this.handleMouseDown},[S(()=>g),o?(H(),W(`div`,{key:0,class:x(`${s}-base-selection__border`)},null,2)):S(()=>null),o?(H(),W(`div`,{key:2,class:x(`${s}-base-selection__state-border`)},null,2)):S(()=>null)],46,Kt)}});function Jt(e){let{boxShadow2:t}=e;return{menuBoxShadow:t}}var Yt=i({name:`Select`,common:E,peers:{InternalSelection:zt,InternalSelectMenu:Ie},self:Jt}),Xt=C([A(`select`,`
 z-index: auto;
 outline: none;
 width: 100%;
 position: relative;
 font-weight: var(--n-font-weight);
 `),A(`select-menu`,`
 margin: 4px 0;
 box-shadow: var(--n-menu-box-shadow);
 `,[I({originalTransition:`background-color .3s var(--n-bezier), box-shadow .3s var(--n-bezier)`})])]),Zt={...r.props,to:F.propTo,bordered:{type:Boolean,default:void 0},clearable:Boolean,clearCreatedOptionsOnClear:{type:Boolean,default:!0},clearFilterAfterSelect:{type:Boolean,default:!0},options:{type:Array,default:()=>[]},defaultValue:{type:[String,Number,Array],default:null},keyboard:{type:Boolean,default:!0},value:[String,Number,Array],placeholder:String,menuProps:Object,multiple:Boolean,size:String,menuSize:{type:String},filterable:Boolean,disabled:{type:Boolean,default:void 0},remote:Boolean,loading:Boolean,filter:Function,placement:{type:String,default:`bottom-start`},widthMode:{type:String,default:`trigger`},tag:Boolean,onCreate:Function,fallbackOption:{type:[Function,Boolean],default:void 0},show:{type:Boolean,default:void 0},showArrow:{type:Boolean,default:!0},maxTagCount:[Number,String],ellipsisTagPopoverProps:Object,consistentMenuWidth:{type:Boolean,default:!0},virtualScroll:{type:Boolean,default:!0},labelField:{type:String,default:`label`},valueField:{type:String,default:`value`},childrenField:{type:String,default:`children`},renderLabel:Function,renderOption:Function,renderTag:Function,"onUpdate:value":[Function,Array],inputProps:Object,nodeProps:Function,ignoreComposition:{type:Boolean,default:!0},showOnFocus:Boolean,onUpdateValue:[Function,Array],onBlur:[Function,Array],onClear:[Function,Array],onFocus:[Function,Array],onScroll:[Function,Array],onSearch:[Function,Array],onUpdateShow:[Function,Array],"onUpdate:show":[Function,Array],displayDirective:{type:String,default:`show`},resetMenuOnOptionsChange:{type:Boolean,default:!0},status:String,showCheckmark:{type:Boolean,default:!0},scrollbarProps:Object,onChange:[Function,Array],items:Array},Qt=B({name:`Select`,props:Zt,slots:Object,setup(e){let{mergedClsPrefixRef:t,mergedBorderedRef:n,namespaceRef:i,inlineThemeDisabled:a,mergedComponentPropsRef:o}=ne(e),s=r(`Select`,`-select`,Xt,Yt,e,t),c=K(e.defaultValue),d=J(e,`value`),f=ae(d,c),p=K(!1),m=K(``),h=we(e,[`items`,`options`]),g=K([]),_=K([]),v=X(()=>_.value.concat(g.value).concat(h.value)),x=X(()=>{let{filter:t}=e;if(t)return t;let{labelField:n,valueField:r}=e;return(e,t)=>{if(!t)return!1;let i=t[n];if(typeof i==`string`)return Pt(e,i);let a=t[r];return typeof a==`string`?Pt(e,a):typeof a==`number`&&Pt(e,String(a))}}),S=X(()=>{if(e.remote)return h.value;{let{value:t}=v,{value:n}=m;return!n.length||!e.filterable?t:It(t,x.value,n,e.childrenField)}}),te=X(()=>{let{valueField:t,childrenField:n}=e,r=Ft(t,n);return kt(S.value,r)}),C=X(()=>Lt(v.value,e.valueField,e.childrenField)),w=K(!1),T=ae(J(e,`show`),w),E=K(null),D=K(null),O=K(null),{localeRef:oe}=u(`Select`),A=X(()=>e.placeholder??oe.value.placeholder),j=[],M=K(new Map),N=X(()=>{let{fallbackOption:t}=e;if(t===void 0){let{labelField:t,valueField:n}=e;return e=>({[t]:String(e),[n]:e})}return t===!1?!1:e=>Object.assign(t(e),{value:e})});function P(t){let n=e.remote,{value:r}=M,{value:i}=C,{value:a}=N,o=[];return t.forEach(e=>{if(i.has(e))o.push(i.get(e));else if(n&&r.has(e))o.push(r.get(e));else if(a){let t=a(e);t&&o.push(t)}}),o}let se=X(()=>{if(e.multiple){let{value:e}=f;return Array.isArray(e)?P(e):[]}return null}),I=X(()=>{let{value:t}=f;return!e.multiple&&!Array.isArray(t)?t===null?null:P([t])[0]||null:null}),L=l(e,{mergedSize:t=>{let{size:n}=e;if(n)return n;let{mergedSize:r}=t||{};return r?.value?r.value:o?.value?.Select?.size||`medium`}}),{mergedSizeRef:ce,mergedDisabledRef:R,mergedStatusRef:le}=L;function z(t,n){let{onChange:r,"onUpdate:value":i,onUpdateValue:a}=e,{nTriggerFormChange:o,nTriggerFormInput:s}=L;r&&k(r,t,n),a&&k(a,t,n),i&&k(i,t,n),c.value=t,o(),s()}function B(t){let{onBlur:n}=e,{nTriggerFormBlur:r}=L;n&&k(n,t),r()}function V(){let{onClear:t}=e;t&&k(t)}function H(t){let{onFocus:n,showOnFocus:r}=e,{nTriggerFormFocus:i}=L;n&&k(n,t),i(),r&&W()}function ue(t){let{onSearch:n}=e;n&&k(n,t)}function U(t){let{onScroll:n}=e;n&&k(n,t)}function de(){let{remote:t,multiple:n}=e;if(t){let{value:t}=M;if(n){let{valueField:n}=e;se.value?.forEach(e=>{t.set(e[n],e)})}else{let n=I.value;n&&t.set(n[e.valueField],n)}}}function fe(t){let{onUpdateShow:n,"onUpdate:show":r}=e;n&&k(n,t),r&&k(r,t),w.value=t}function W(){R.value||(fe(!0),w.value=!0,e.filterable&&Ne())}function G(){fe(!1)}function pe(){m.value=``,_.value=j}let me=K(!1);function q(){e.filterable&&(me.value=!0)}function ge(){e.filterable&&(me.value=!1,T.value||pe())}function Y(){R.value||(T.value?e.filterable?Ne():G():W())}function _e(e){O.value?.selfRef?.contains(e.relatedTarget)||(p.value=!1,B(e),G())}function ve(e){H(e),p.value=!0}function ye(){p.value=!0}function be(e){E.value?.$el.contains(e.relatedTarget)||(p.value=!1,B(e),G())}function Z(){E.value?.focus(),G()}function xe(e){T.value&&(E.value?.$el.contains(re(e))||G())}function Se(t){if(!Array.isArray(t))return[];if(N.value)return Array.from(t);{let{remote:n}=e,{value:r}=C;if(n){let{value:e}=M;return t.filter(t=>r.has(t)||e.has(t))}return t.filter(e=>r.has(e))}}function Ce(e){Te(e.rawNode)}function Te(t){if(R.value)return;let{tag:n,remote:r,clearFilterAfterSelect:i,valueField:a}=e;if(n&&!r){let{value:e}=_,t=e[0]||null;if(t){let e=g.value;e.length?e.push(t):g.value=[t],_.value=j}}if(r&&M.value.set(t[a],t),e.multiple){let e=Se(f.value),o=e.findIndex(e=>e===t[a]);if(~o){if(e.splice(o,1),n&&!r){let e=Ee(t[a]);~e&&(g.value.splice(e,1),i&&(m.value=``))}}else e.push(t[a]),i&&(m.value=``);z(e,P(e))}else{if(n&&!r){let e=Ee(t[a]);~e?g.value=[g.value[e]]:g.value=j}Me(),G(),z(t[a],t)}}function Ee(t){return g.value.findIndex(n=>n[e.valueField]===t)}function De(t){T.value||W();let{value:n}=t.target;m.value=n;let{tag:r,remote:i}=e;if(ue(n),r&&!i){if(!n){_.value=j;return}let{onCreate:t}=e,r=t?t(n):{[e.labelField]:n,[e.valueField]:n},{valueField:i,labelField:a}=e;h.value.some(e=>e[i]===r[i]||e[a]===r[a])||g.value.some(e=>e[i]===r[i]||e[a]===r[a])?_.value=j:_.value=[r]}}function Oe(t){t.stopPropagation();let{multiple:n,tag:r,remote:i,clearCreatedOptionsOnClear:a}=e;!n&&e.filterable&&G(),r&&!i&&a&&(g.value=j),V(),n?z([],[]):z(null,null)}function ke(e){b(e,`action`)||b(e,`empty`)||b(e,`header`)||e.preventDefault()}function Ae(e){U(e)}function je(t){if(!e.keyboard)t.preventDefault();else switch(t.key){case` `:if(e.filterable)break;t.preventDefault();case`Enter`:if(!E.value?.isComposing){if(T.value){let t=O.value?.getPendingTmNode();t?Ce(t):e.filterable||(G(),Me())}else if(W(),e.tag&&me.value){let t=_.value[0];if(t){let n=t[e.valueField],{value:r}=f;e.multiple&&Array.isArray(r)&&r.includes(n)||Te(t)}}}t.preventDefault();break;case`ArrowUp`:if(t.preventDefault(),e.loading)return;T.value&&O.value?.prev();break;case`ArrowDown`:if(t.preventDefault(),e.loading)return;T.value?O.value?.next():W();break;case`Escape`:T.value&&(y(t),G()),E.value?.focus()}}function Me(){E.value?.focus()}function Ne(){E.value?.focusInput()}function Pe(){T.value&&D.value?.syncPosition()}de(),he(J(e,`options`),de);let Fe={focus:()=>{E.value?.focus()},focusInput:()=>{E.value?.focusInput()},blur:()=>{E.value?.blur()},blurInput:()=>{E.value?.blurInput()}},Ie=X(()=>{let{self:{menuBoxShadow:e}}=s.value;return{"--n-menu-box-shadow":e}}),Q=a?ie(`select`,void 0,Ie,e):void 0;return{...Fe,mergedStatus:le,mergedClsPrefix:t,mergedBordered:n,namespace:i,treeMate:te,isMounted:ee(),triggerRef:E,menuRef:O,pattern:m,uncontrolledShow:w,mergedShow:T,adjustedTo:F(e),uncontrolledValue:c,mergedValue:f,followerRef:D,localizedPlaceholder:A,selectedOption:I,selectedOptions:se,mergedSize:ce,mergedDisabled:R,focused:p,activeWithoutMenuOpen:me,inlineThemeDisabled:a,onTriggerInputFocus:q,onTriggerInputBlur:ge,handleTriggerOrMenuResize:Pe,handleMenuFocus:ye,handleMenuBlur:be,handleMenuTabOut:Z,handleTriggerClick:Y,handleToggle:Ce,handleDeleteOption:Te,handlePatternInput:De,handleClear:Oe,handleTriggerBlur:_e,handleTriggerFocus:ve,handleKeydown:je,handleMenuAfterLeave:pe,handleMenuClickOutside:xe,handleMenuScroll:Ae,handleMenuKeydown:je,handleMenuMousedown:ke,mergedTheme:s,cssVars:a?void 0:Ie,themeClass:Q?.themeClass,onRender:Q?.onRender}},render(){return H(),W(`div`,{class:x(`${this.mergedClsPrefix}-select`)},[G(g,null,{_:1,default:D(()=>[(H(),q(c,null,{_:1,default:D(()=>(H(),q(qt,{ref:`triggerRef`,inlineThemeDisabled:this.inlineThemeDisabled,status:this.mergedStatus,inputProps:this.inputProps,clsPrefix:this.mergedClsPrefix,showArrow:this.showArrow,maxTagCount:this.maxTagCount,ellipsisTagPopoverProps:this.ellipsisTagPopoverProps,bordered:this.mergedBordered,active:this.activeWithoutMenuOpen||this.mergedShow,pattern:this.pattern,placeholder:this.localizedPlaceholder,selectedOption:this.selectedOption,selectedOptions:this.selectedOptions,multiple:this.multiple,renderTag:this.renderTag,renderLabel:this.renderLabel,filterable:this.filterable,clearable:this.clearable,disabled:this.mergedDisabled,size:this.mergedSize,theme:this.mergedTheme.peers.InternalSelection,labelField:this.labelField,valueField:this.valueField,themeOverrides:this.mergedTheme.peerOverrides.InternalSelection,loading:this.loading,focused:this.focused,onClick:this.handleTriggerClick,onDeleteOption:this.handleDeleteOption,onPatternInput:this.handlePatternInput,onClear:this.handleClear,onBlur:this.handleTriggerBlur,onFocus:this.handleTriggerFocus,onKeydown:this.handleKeydown,onPatternBlur:this.onTriggerInputBlur,onPatternFocus:this.onTriggerInputFocus,onResize:this.handleTriggerOrMenuResize,ignoreComposition:this.ignoreComposition},{_:1,arrow:D(()=>[this.$slots.arrow?.()])},8,`inlineThemeDisabled.status.inputProps.clsPrefix.showArrow.maxTagCount.ellipsisTagPopoverProps.bordered.active.pattern.placeholder.selectedOption.selectedOptions.multiple.renderTag.renderLabel.filterable.clearable.disabled.size.theme.labelField.valueField.themeOverrides.loading.focused.onClick.onDeleteOption.onPatternInput.onClear.onBlur.onFocus.onKeydown.onPatternBlur.onPatternFocus.onResize.ignoreComposition`.split(`.`))))})),(H(),q(s,{ref:`followerRef`,show:this.mergedShow,to:this.adjustedTo,teleportDisabled:this.adjustedTo===F.tdkey,containerClass:this.namespace,width:this.consistentMenuWidth?`target`:void 0,minWidth:`target`,placement:this.placement},{_:1,default:D(()=>(H(),q(_e,{name:`fade-in-scale-up-transition`,appear:this.isMounted,onAfterLeave:this.handleMenuAfterLeave},{_:1,default:D(()=>this.mergedShow||this.displayDirective===`show`?(this.onRender?.(),fe((H(),q(jt,U(this.menuProps,{ref:`menuRef`,onResize:this.handleTriggerOrMenuResize,inlineThemeDisabled:this.inlineThemeDisabled,virtualScroll:this.consistentMenuWidth&&this.virtualScroll,class:[`${this.mergedClsPrefix}-select-menu`,this.themeClass,this.menuProps?.class],clsPrefix:this.mergedClsPrefix,focusable:!0,labelField:this.labelField,valueField:this.valueField,autoPending:!0,nodeProps:this.nodeProps,theme:this.mergedTheme.peers.InternalSelectMenu,themeOverrides:this.mergedTheme.peerOverrides.InternalSelectMenu,treeMate:this.treeMate,multiple:this.multiple,size:this.menuSize,renderOption:this.renderOption,renderLabel:this.renderLabel,value:this.mergedValue,style:[this.menuProps?.style,this.cssVars],onToggle:this.handleToggle,onScroll:this.handleMenuScroll,onFocus:this.handleMenuFocus,onBlur:this.handleMenuBlur,onKeydown:this.handleMenuKeydown,onTabOut:this.handleMenuTabOut,onMousedown:this.handleMenuMousedown,show:this.mergedShow,showCheckmark:this.showCheckmark,resetMenuOnOptionsChange:this.resetMenuOnOptionsChange,scrollbarProps:this.scrollbarProps}),{_:1,empty:D(()=>[this.$slots.empty?.()]),header:D(()=>[this.$slots.header?.()]),action:D(()=>[this.$slots.action?.()])},16,`onResize.inlineThemeDisabled.virtualScroll.class.clsPrefix.labelField.valueField.nodeProps.theme.themeOverrides.treeMate.multiple.size.renderOption.renderLabel.value.style.onToggle.onScroll.onFocus.onBlur.onKeydown.onTabOut.onMousedown.show.showCheckmark.resetMenuOnOptionsChange.scrollbarProps`.split(`.`))),this.displayDirective===`show`?[[ye,this.mergedShow],[M,this.handleMenuClickOutside,void 0,{capture:!0}]]:[[M,this.handleMenuClickOutside,void 0,{capture:!0}]])):null)},8,[`appear`,`onAfterLeave`])))},8,[`show`,`to`,`teleportDisabled`,`containerClass`,`width`,`placement`]))])})],2)}});export{Re as _,zt as a,Me as b,kt as c,dt as d,We as f,Be as g,Ve as h,qt as i,Et as l,$ as m,Zt as n,Ft as o,Ue as p,Yt as r,jt as s,Qt as t,ft as u,Ie as v,ke as x,Ne as y};
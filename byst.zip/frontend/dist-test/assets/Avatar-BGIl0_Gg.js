import{B as e,Dt as t,It as n,L as r,br as i,cn as a,dn as o,fr as s,gn as c,hr as l,jt as u,kt as d,pr as f,rt as p,tt as m,vr as h,yn as g,yr as _}from"./Skeleton-DVjzRZkO.js";import{n as v}from"./Tag-BOvzHE0n.js";import{D as y,O as b}from"./Upload-Cmj6Ovx5.js";import{A as x,E as S,H as C,I as w,S as T,X as E,Y as D,at as O,b as k,k as A,pt as j,v as M,z as N}from"./vue-vendor-BGcTsaF8.js";function P(e){let{borderRadius:t,avatarColor:r,cardColor:i,fontSize:a,heightTiny:o,heightSmall:s,heightMedium:c,heightLarge:l,heightHuge:u,modalColor:d,popoverColor:f}=e;return{borderRadius:t,fontSize:a,border:`2px solid ${i}`,heightTiny:o,heightSmall:s,heightMedium:c,heightLarge:l,heightHuge:u,color:n(i,r),colorModal:n(d,r),colorPopover:n(f,r)}}var F={name:`Avatar`,common:u,self:P},I=g(`n-avatar-group`),L=f(`avatar`,`
 width: var(--n-merged-size);
 height: var(--n-merged-size);
 color: #FFF;
 font-size: var(--n-font-size);
 display: inline-flex;
 position: relative;
 overflow: hidden;
 text-align: center;
 border: var(--n-border);
 border-radius: var(--n-border-radius);
 --n-merged-color: var(--n-color);
 background-color: var(--n-merged-color);
 transition:
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[_(s(`&`,`--n-merged-color: var(--n-color-modal);`)),i(s(`&`,`--n-merged-color: var(--n-color-popover);`)),s(`img`,`
 width: 100%;
 height: 100%;
 `),l(`text`,`
 white-space: nowrap;
 display: inline-block;
 position: absolute;
 left: 50%;
 top: 50%;
 `),f(`icon`,`
 vertical-align: bottom;
 font-size: calc(var(--n-merged-size) - 6px);
 `),l(`text`,`line-height: 1.25`)]),R=[`src`],z={...t.props,size:[String,Number],src:String,circle:{type:Boolean,default:void 0},objectFit:String,round:{type:Boolean,default:void 0},bordered:{type:Boolean,default:void 0},onError:Function,fallbackSrc:String,intersectionObserverOptions:Object,lazy:Boolean,onLoad:Function,renderPlaceholder:Function,renderFallback:Function,imgProps:Object,color:String},B=S({name:`Avatar`,props:z,slots:Object,setup(e){let{mergedClsPrefixRef:n,inlineThemeDisabled:i}=c(e),a=O(!1),o=null,s=O(null),l=O(null),u=()=>{let{value:e}=s;if(e&&(o===null||o!==e.innerHTML)){o=e.innerHTML;let{value:t}=l;if(t){let{offsetWidth:n,offsetHeight:r}=t,{offsetWidth:i,offsetHeight:a}=e,o=.9,s=Math.min(n/i*o,r/a*o,1);e.style.transform=`translateX(-50%) translateY(-50%) scale(${s})`}}},f=x(I,null),p=M(()=>{let{size:t}=e;if(t)return t;let{size:n}=f||{};return n||`medium`}),m=t(`Avatar`,`-avatar`,L,F,e,n),g=x(v,null),_=M(()=>{if(f)return!0;let{round:t,circle:n}=e;return t!==void 0||n!==void 0?t||n:g?g.roundRef.value:!1}),b=M(()=>f?!0:e.bordered||!1),S=M(()=>{let t=p.value,n=_.value,r=b.value,{color:i}=e,{self:{borderRadius:a,fontSize:o,color:s,border:c,colorModal:l,colorPopover:u},common:{cubicBezierEaseInOut:d}}=m.value,f;return f=typeof t==`number`?`${t}px`:m.value.self[h(`height`,t)],{"--n-font-size":o,"--n-border":r?c:`none`,"--n-border-radius":n?`50%`:a,"--n-color":i||s,"--n-color-modal":i||l,"--n-color-popover":i||u,"--n-bezier":d,"--n-merged-size":`var(--n-avatar-size-override, ${f})`}}),C=i?d(`avatar`,M(()=>{let t=p.value,n=_.value,i=b.value,{color:a}=e,o=``;return t&&(o+=typeof t==`number`?`a${t}`:t[0]),n&&(o+=`b`),i&&(o+=`c`),a&&(o+=r(a)),o}),S,e):void 0,T=O(!e.lazy);N(()=>{if(e.lazy&&e.intersectionObserverOptions){let t,n=E(()=>{t?.(),t=void 0,e.lazy&&(t=y(l.value,e.intersectionObserverOptions,T))});w(()=>{n(),t?.()})}}),D(()=>e.src||e.imgProps?.src,()=>{a.value=!1});let k=O(!e.lazy);return{textRef:s,selfRef:l,mergedRoundRef:_,mergedClsPrefix:n,fitTextTransform:u,cssVars:i?void 0:S,themeClass:C?.themeClass,onRender:C?.onRender,hasLoadError:a,shouldStartLoading:T,loaded:k,mergedOnError:t=>{if(!T.value)return;a.value=!0;let{onError:n,imgProps:{onError:r}={}}=e;n?.(t),r?.(t)},mergedOnLoad:t=>{let{onLoad:n,imgProps:{onLoad:r}={}}=e;n?.(t),r?.(t),k.value=!0}}},render(){let{$slots:t,src:n,mergedClsPrefix:r,lazy:i,onRender:s,loaded:c,hasLoadError:l,imgProps:u={}}=this;s?.();let d,f=!c&&!l&&(this.renderPlaceholder?this.renderPlaceholder():this.$slots.placeholder?.());return d=this.hasLoadError?this.renderFallback?this.renderFallback():m(t.fallback,()=>[(C(),T(`img`,{src:this.fallbackSrc,style:j({objectFit:this.objectFit})},null,12,R))]):p(t.default,t=>{if(t)return C(),k(e,{key:1,onResize:this.fitTextTransform},{default:()=>(C(),T(`span`,{ref:`textRef`,class:a(`${r}-avatar__text`)},[o(()=>t)],2))},1032,[`onResize`]);if(n||u.src){let e=this.src||u.src;return A(`img`,{...u,loading:b&&!this.intersectionObserverOptions&&i?`lazy`:`eager`,src:i&&this.intersectionObserverOptions?this.shouldStartLoading?e:void 0:e,"data-image-src":e,onLoad:this.mergedOnLoad,onError:this.mergedOnError,style:[u.style||``,{objectFit:this.objectFit},f?{height:`0`,width:`0`,visibility:`hidden`,position:`absolute`}:``]})}}),C(),T(`span`,{ref:`selfRef`,class:a([`${r}-avatar`,this.themeClass]),style:j(this.cssVars)},[o(()=>d),o(()=>i&&f)],6)}});export{F as i,z as n,I as r,B as t};